'use strict';
const gridSteps=km=>[km/111.32,km/(111.32*Math.cos(36*Math.PI/180))];
function gridIndex(r,km){const [dy,dx]=gridSteps(km);return Math.floor(r.lat/dy)+':'+Math.floor(r.lon/dx);}
function aggregateGrid(records,km){const cells=new Map();for(const r of records){if(!mapped(r))continue;const key=gridIndex(r,km);if(!cells.has(key))cells.set(key,[]);cells.get(key).push(r);}return cells;}
function gridBounds(key,km){const [iy,ix]=key.split(':').map(Number),[dy,dx]=gridSteps(km);return [[iy*dy,ix*dx],[(iy+1)*dy,(ix+1)*dx]];}
function featureName(f){let p=f.properties||{};return p.name_ja||p.nam_ja||p.N03_001||p.prefecture||p.name||p.NAME_JA||'';}
let focusedPref=null,prefFocusRenderer;
function prefectureMaskRings(feature){
 const geometry=feature?.geometry;
 const polygons=geometry?.type==='Polygon'?[geometry.coordinates]:geometry?.type==='MultiPolygon'?geometry.coordinates:[];
 const world=[[-85,-180],[-85,180],[85,180],[85,-180]];
 return [world,...polygons.flatMap(polygon=>polygon.map(ring=>ring.map(([lon,lat])=>[lat,lon])))];
}
function syncPrefectureFocus(){
 if(!map)return;
 const name=$('#pref').value;
 if(focusedPref===name)return;
 if(prefLayer){map.removeLayer(prefLayer);prefLayer=null;}
 focusedPref=name;
 const feature=prefFeatures?.features.find(f=>featureName(f)===name);
 if(!name||!feature)return;
 const mask=L.polygon(prefectureMaskRings(feature),{pane:'prefectureFocus',renderer:prefFocusRenderer,stroke:false,fillColor:'#747b82',fillOpacity:.43,fillRule:'evenodd',interactive:false,className:'prefecture-outside-mask'});
 const border=L.geoJSON(feature,{pane:'prefectureFocus',renderer:prefFocusRenderer,style:{color:'#b85420',weight:2.2,opacity:.95,fill:false,fillOpacity:0},interactive:false,className:'selected-prefecture-boundary'});
 prefLayer=L.featureGroup([mask,border]).addTo(map);
}
function fitJapan(){map?.fitBounds([[24.1,123],[45.7,146.1]],{padding:[25,25],animate:false});}
function initMap(){
 if(!window.L){$('#map-error').hidden=false;$('#map-error').textContent=t('地図を読み込めません。データ一覧をご利用ください。','Map unavailable. Please use the record list.');return;}
 map=L.map('map',{zoomControl:false,minZoom:3,maxZoom:18,zoomSnap:.5,preferCanvas:true,attributionControl:true});
 const focusPane=map.createPane('prefectureFocus');focusPane.style.zIndex='450';focusPane.style.pointerEvents='none';prefFocusRenderer=L.svg({pane:'prefectureFocus'});
 L.DomEvent.disableClickPropagation($('#legend'));L.DomEvent.disableScrollPropagation($('#legend'));
 L.control.zoom({position:'topright'}).addTo(map);L.control.scale({imperial:false,position:'bottomright'}).addTo(map);fitJapan();
 if(prefFeatures)outline=L.geoJSON(prefFeatures,{style:{color:'#8d8078',weight:.5,fill:false,fillOpacity:0,opacity:.35},interactive:false}).addTo(map);
 tileLayer=L.tileLayer('https://cyberjapandata.gsi.go.jp/xyz/pale/{z}/{x}/{y}.png',{minZoom:3,minNativeZoom:5,maxZoom:18,opacity:.62,className:'atlas-base-tiles',attribution:'<a href="https://maps.gsi.go.jp/development/ichiran.html" target="_blank" rel="noopener">地理院タイル / GSI</a>'}).addTo(map);
 tileLayer.on('tileerror',()=>{$('#map-error').hidden=false;$('#map-error').textContent=t('背景地図を取得できません。位置の表示は継続しています。','Base map unavailable; record locations remain visible.');});
 tileLayer.on('tileload',()=>$('#map-error').hidden=true);
 map.on('moveend',()=>{if($('#in-bounds').checked)applyFilters();});
 map.attributionControl.addAttribution('<a href="https://github.com/dataofjapan/land" target="_blank" rel="noopener">Boundary: dataofjapan / GSI</a> · <a href="https://www.mlit.go.jp/road/sisaku/ijikanri/dourokanbotsu.html" target="_blank" rel="noopener">Data: MLIT (edited)</a>');
}
function clusterIcon(count){const size=count>=1000?64:count>=100?56:count>=10?48:40;return L.divIcon({className:'cluster-icon '+(count>=100?'large':''),html:'<span>'+fmt(count)+'</span>',iconSize:[size,size],iconAnchor:[size/2,size/2]});}
const gridPalette=[[255,242,196],[249,150,53],[158,47,7]];
function gridColorAt(fraction){
 const x=Math.max(0,Math.min(1,fraction))*(gridPalette.length-1),i=Math.min(gridPalette.length-2,Math.floor(x)),blend=x-i;
 return 'rgb('+gridPalette[i].map((v,c)=>Math.round(v+(gridPalette[i+1][c]-v)*blend)).join(',')+')';
}
let manualGridLimits=null,gridScaleSignature='',currentGridCells=null,currentScaleCells=null,densityCells=[],currentGridKm=10;
function normalizeGridLimits(max,limits){
 if(max<=0)return {lower:0,upper:1};
 const upper=Math.max(1,Math.min(max,Math.round(limits?.upper??max)));
 const lower=Math.max(0,Math.min(upper-1,Math.round(limits?.lower??0)));
 return {lower,upper};
}
function buildGridScale(cells,limits=null){
 const max=[...cells.values()].reduce((n,rs)=>Math.max(n,rs.length),0),{lower,upper}=normalizeGridLimits(max,limits);
 return {max,lower,upper,color:n=>max>0&&n>0?gridColorAt((n-lower)/(upper-lower)):'transparent',gradient:'linear-gradient(90deg in srgb, '+gridPalette.map(rgb=>'rgb('+rgb.join(',')+')').join(', ')+')'};
}
function prepareGridScale(cells,km){
 const playbackCells=typeof playbackScaleCells==='function'?playbackScaleCells(km):null;
 const signature=playbackCells?'playback|'+playback.signature+'|'+playback.mode+'|'+km:scope+'|'+km+'|'+[...cells].map(([key,rs])=>key+':'+rs.length).sort().join('|');
 if(signature!==gridScaleSignature){manualGridLimits=null;gridScaleSignature=signature;}
 currentGridCells=cells;currentScaleCells=playbackCells||cells;currentGridKm=km;
 return buildGridScale(currentScaleCells,manualGridLimits);
}
function gridLegend(scale,km){
 return '<strong>'+t('メッシュ内の記録数','Records per grid cell')+'</strong><small>'+t('約'+km+' km四方・緯度36°基準','Approx. '+km+' km square at 36°N')+'</small>'
 +(scale.max?'<div class="gradient-scale" role="img" id="gradient-scale"><div class="gradient-strip" style="background:'+scale.gradient+'"></div><div class="gradient-labels"><span id="scale-low">'+fmt(scale.lower)+'</span><span id="scale-high">'+fmt(scale.upper)+t('件',' records')+'</span></div></div>'
 +'<div class="legend-ranges"><label for="color-min">'+t('色の下限','Color minimum')+'</label><input type="range" id="color-min" min="0" max="'+Math.max(0,scale.max-1)+'" step="1" value="'+scale.lower+'"><output id="color-min-value">'+fmt(scale.lower)+'</output>'
 +'<label for="color-max">'+t('色の上限','Color maximum')+'</label><input type="range" id="color-max" min="1" max="'+scale.max+'" step="1" value="'+scale.upper+'"><output id="color-max-value">'+fmt(scale.upper)+'</output></div>'
 +'<div class="legend-scale-status"><small>'+(typeof playback!=='undefined'&&playback.active?t('再生期間内の最大：','Playback maximum: '):t('実際の最大：','Observed maximum: '))+fmt(scale.max)+t('件',' records')+'</small><button id="color-auto">'+t('自動に戻す','Auto scale')+'</button></div>'
 +'<small class="scale-note">'+t('範囲外は最淡色・最濃色で表示。件数は絞り込みません。条件を変えると自動調整に戻ります。','Outside this range, colors stay at the lightest or darkest shade. Records are not filtered. Changing filters resets the scale.')+'</small>'
 :'<small>'+t('地図に表示できる記録がありません','No located records')+'</small>');
}
function updateGridLegendUI(scale){
 $('#color-min').value=scale.lower;$('#color-max').value=scale.upper;
 $('#color-min').disabled=scale.max<=1;$('#color-max').disabled=scale.max<=1;
 $('#color-min-value').textContent=fmt(scale.lower);$('#color-max-value').textContent=fmt(scale.upper);
 $('#scale-low').textContent=fmt(scale.lower);$('#scale-high').textContent=fmt(scale.upper)+t('件',' records');
 $('#gradient-scale').setAttribute('aria-label',t(scale.lower+'件から'+scale.upper+'件までの連続色分け','Continuous color scale from '+scale.lower+' to '+scale.upper+' records'));
 $('#color-min').setAttribute('aria-valuetext',fmt(scale.lower)+t('件',' records'));$('#color-max').setAttribute('aria-valuetext',fmt(scale.upper)+t('件',' records'));
 $('#color-auto').disabled=manualGridLimits===null;
}
function recolorGrid(){
 const scale=buildGridScale(currentScaleCells||currentGridCells,manualGridLimits);
 for(const {layer,count} of densityCells)layer.setStyle({color:scale.color(count),fillColor:scale.color(count)});
 updateGridLegendUI(scale);
 if(typeof updateMobileUI==='function')updateMobileUI();
}
function changeGridColorBound(side,value){
 if(!currentGridCells)return;
 const scale=buildGridScale(currentScaleCells||currentGridCells,manualGridLimits),v=Math.round(Number(value));
 if(!Number.isFinite(v)||scale.max<1)return;
 manualGridLimits={lower:scale.lower,upper:scale.upper};
 if(side==='min')manualGridLimits.lower=Math.max(0,Math.min(v,scale.upper-1));
 else manualGridLimits.upper=Math.max(scale.lower+1,Math.min(v,scale.max));
 recolorGrid();
}
function wireGridLegend(scale){
 if(!scale.max)return;
 $('#color-min').oninput=()=>changeGridColorBound('min',$('#color-min').value);
 $('#color-max').oninput=()=>changeGridColorBound('max',$('#color-max').value);
 $('#color-auto').onclick=()=>{manualGridLimits=null;recolorGrid();};
 updateGridLegendUI(scale);
 if(typeof updateMobileUI==='function')updateMobileUI();
}
function depthRange(rs){const values=rs.map(r=>r.depthM).filter(num);return values.length?fmt(Math.min(...values))+'–'+fmt(Math.max(...values))+' m':t('未記載','Not reported');}
function recordTooltip(r){return `<div class="record-tooltip"><strong>${esc(recordTitle(r))}</strong><span>${esc(prefLabel(r.prefecture))} · ${esc(dateLabel(r))}</span><span>${esc(r.address)}</span><b>${t('深さ','Depth')} ${num(r.depthM)?fmt(r.depthM)+' m':t('未記載','not reported')}</b><span>${t('縦 × 横','Length × width')}: ${dim(r.lengthM)} × ${dim(r.widthM)} m</span><span>${esc(causeLabel(caseField(r,'cause')||r.cause))}</span><small>${esc(shortPrecision(r))} · ${t('クリックで詳細','Click for details')}</small></div>`;}
function groupTooltip(rs,heading){const coarse=rs.filter(r=>precisionCode(r)==='city').length;return `<div class="record-tooltip"><strong>${esc(heading)} · ${fmt(rs.length)} ${t('件','records')}</strong><span>${t('深さ','Depth')}: ${depthRange(rs)}</span><span>${t('市区町村までの住所','Municipality-only locations')}: ${fmt(coarse)}</span>${rs.slice(0,3).map(r=>`<span>• ${esc(recordTitle(r))} / ${num(r.depthM)?fmt(r.depthM)+' m':'—'}</span>`).join('')}<small>${t('代表位置の集計です。クリックして記録を確認。','Aggregated representative locations. Click to inspect records.')}</small></div>`;}
function pointPopup(k,rs){return `${groupTooltip(rs,t('同じ代表位置','Shared representative location'))}<div class="popup-records">${rs.slice(0,8).map(r=>`<button class="popup-record" data-record="${esc(r.id)}">${esc(recordTitle(r))}<small>${esc(dateLabel(r))} · ${t('深さ','Depth')} ${dim(r.depthM)} m</small></button>`).join('')}</div><button data-point="${esc(k)}">${t('この位置の全記録を表示','List all records at this position')} (${fmt(rs.length)}) →</button>`;}
function updateMapNotice(){
 const coarse=filtered.filter(r=>precisionCode(r)==='city').length;
 $('#map-notice').innerHTML=`<span>ⓘ</span><span>${mode==='density'?t('色はメッシュ内の記録数。','Color shows records per grid cell.'):t('カーソルで概要、クリックで詳細。','Hover for a summary; click for details.')} ${t('点は住所の代表位置です。','Points are representative locations.')} ${coarse?t(`市区町村までの ${fmt(coarse)} 件は同じ位置に重なるため、細かな分布は「町丁目まで分かる」で確認してください。`,`${fmt(coarse)} municipality-only records may overlap. Choose “Neighborhood identified” for finer patterns.`):''}</span>`;
}
function clearMapData(){densityCells=[];if(clusters){map.removeLayer(clusters);clusters.clearLayers();clusters=null;}if(densityLayer){map.removeLayer(densityLayer);densityLayer=null;}if(selectedLayer){map.removeLayer(selectedLayer);selectedLayer=null;}}
function renderMap(){
 if(!map)return;syncPrefectureFocus();clearMapData();$('#mode-density').classList.toggle('active',mode==='density');$('#mode-cluster').classList.toggle('active',mode==='cluster');$('#density-options').hidden=mode!=='density';updateMapNotice();
 if(mode==='density'){
  const km=Number($('#grid-size').value)||10,opacity=(Number($('#overlay-opacity').value)||0)/100,cells=aggregateGrid(filtered,km),scale=prepareGridScale(cells,km);densityLayer=L.featureGroup().addTo(map);
  for(const [key,rs] of cells){const rect=L.rectangle(gridBounds(key,km),{color:scale.color(rs.length),weight:.4,opacity:opacity?Math.min(opacity+.15,.7):0,fillColor:scale.color(rs.length),fillOpacity:opacity});
   rect.bindTooltip(groupTooltip(rs,t('約'+km+' kmメッシュ','Approx. '+km+' km cell')),{sticky:true,className:'atlas-tooltip',direction:'top'});
   rect.bindPopup(groupTooltip(rs,t('約'+km+' kmメッシュ','Approx. '+km+' km cell'))+`<button data-cell="${key}" data-size="${km}">${t('この範囲を点で確認','Inspect this cell as points')} →</button>`);
   densityLayer.addLayer(rect);densityCells.push({layer:rect,count:rs.length});
  }
  $('#legend').innerHTML=gridLegend(scale,km);wireGridLegend(scale);
 }else{
  $('#legend').innerHTML=`<strong>${t('原因・要因施設','Cause / related facility')}</strong>`+Object.entries(colors).map(([label,color])=>`<span><i style="background:${color}"></i>${esc(causeLabel(label))}</span>`).join('');
  const groups=new Map();filtered.filter(mapped).forEach(r=>{const k=keyPoint(r);if(!groups.has(k))groups.set(k,[]);groups.get(k).push(r);});
  clusters=L.markerClusterGroup({showCoverageOnHover:false,maxClusterRadius:45,animate:false,spiderfyOnMaxZoom:false,iconCreateFunction:c=>clusterIcon(c.getAllChildMarkers().reduce((s,m)=>s+m.options.records.length,0))});
  const markers=[];for(const [k,rs] of groups){const r=rs[0],marker=L.marker([r.lat,r.lon],{records:rs,keyboard:true,title:recordTitle(r),icon:rs.length>1?clusterIcon(rs.length):L.divIcon({className:'event-dot',html:`<span style="background:${colors[causeGroup(r)]}"></span>`,iconSize:[20,20],iconAnchor:[10,10]})});
   marker.bindTooltip(rs.length===1?recordTooltip(r):groupTooltip(rs,t('同じ代表位置','Shared location')),{direction:'top',offset:[0,-12],className:'atlas-tooltip'});
   if(rs.length===1)marker.on('click',()=>openDetail(r.id,false));else marker.bindPopup(pointPopup(k,rs));markers.push(marker);
  }
  clusters.on('clustermouseover',e=>{const rs=e.layer.getAllChildMarkers().flatMap(m=>m.options.records);e.layer.bindTooltip(groupTooltip(rs,t('この範囲の記録','Records in this area')),{direction:'top',className:'atlas-tooltip'}).openTooltip();});
  clusters.on('clustermouseout',e=>e.layer.closeTooltip());clusters.addLayers(markers);map.addLayer(clusters);
 }
 showSelectedPoint();
 if(typeof updateMobileUI==='function')updateMobileUI();
}
function showSelectedPoint(){
 if(!map)return;if(selectedLayer){map.removeLayer(selectedLayer);selectedLayer=null;}
 const r=ids.get(selected);if(!r||!mapped(r)||(typeof playback!=='undefined'&&playback.active&&!filtered.some(item=>item.id===r.id)))return;
 selectedLayer=L.circleMarker([r.lat,r.lon],{radius:12,color:'#752805',weight:3,fillColor:'#fff3d4',fillOpacity:.85}).addTo(map).bindTooltip(recordTooltip(r),{className:'atlas-tooltip'}).on('click',()=>openDetail(r.id,false));
}

'use strict';
let datasetIntegrity={},runtimeCheck=null,auditQueue='notes',auditLimit=40,auditBusy=false;
const auditIssues=r=>auditData?.issues?.[r.id]||[];
const issueText=i=>lang==='en'?i.messageEn:i.messageJa;
function sourceMatched(r){
 if(r.timeline||!auditData)return false;
 const file=auditData.files.find(f=>f.fiscalYear===r.fiscalYear);
 return file&&datasetIntegrity[file.datasetFile]==='match'&&file.checkedSourceRows.some(s=>s.sheet===r.sourceSheet&&s.rowRanges.some(([a,b])=>r.sourceRow>=a&&r.sourceRow<=b))&&!auditIssues(r).some(i=>i.kind==='transcription_mismatch');
}
async function hashBytes(bytes){if(!globalThis.crypto?.subtle)return null;return [...new Uint8Array(await crypto.subtle.digest('SHA-256',bytes))].map(b=>b.toString(16).padStart(2,'0')).join('');}
async function fetchRecords(file){
 const response=await fetch(file);if(!response.ok)throw Error(file);const bytes=await response.arrayBuffer(),hash=await hashBytes(bytes),expected=auditData?.files.find(f=>f.datasetFile===file)?.datasetSha256;
 datasetIntegrity[file]=!hash||!expected?'unverified':hash===expected?'match':'mismatch';
 return JSON.parse(new TextDecoder().decode(bytes));
}
function runStructuralChecks(records=national){
 const seen=new Set(),errors=[];
 for(const r of records){
  if(seen.has(r.id))errors.push({id:r.id,kind:'duplicate_id'});seen.add(r.id);
  if(!r.sourceUrl||!r.sourceSheet||!Number.isInteger(r.sourceRow))errors.push({id:r.id,kind:'source_missing'});
  if(['depthM','lengthM','widthM'].some(k=>r[k]!==null&&(!num(r[k])||r[k]<0)))errors.push({id:r.id,kind:'invalid_dimension'});
  if((r.lat!==null||r.lon!==null)&&!mapped(r))errors.push({id:r.id,kind:'invalid_coordinates'});
 }
 return {checkedAt:new Date().toISOString(),records:records.length,errors,datasetIntegrity:{...datasetIntegrity}};
}
function renderRecordAudit(r){
 const notes=auditIssues(r),status=sourceMatched(r)?t('原Excelとの転記一致','Transcription matches retained XLSX'):r.timeline?t('個別資料の再照合は未実施','Case documents not re-audited'):t('配信データの照合未完了','Dataset integrity not verified');
 return `<section class="record-audit"><h4>${t('ファクトチェック：確認できた範囲','Fact check: scope of evidence')}</h4><span class="audit-badge ${sourceMatched(r)?'checked':'pending'}">${status}</span><p>${r.timeline?t('年表と要約には出典を付けていますが、今回の全件Excel照合の対象ではありません。','The narrative and timeline cite sources but are outside the all-record XLSX comparison.'):t('住所・路線・管理者・要因・寸法等13項目の転記を照合。資料に書かれた内容自体の正しさや最新状況は、別途確認が必要です。','13 fields, including address, road, authority, cause and dimensions, were compared. This does not establish the factual accuracy of the source or current conditions.')}</p>${notes.map(i=>'<p class="audit-warning"><b>'+t('確認が必要な注記','Review note')+'</b><br>'+esc(issueText(i))+'</p>').join('')}<p>${t('事故の正確な座標・現在の安全性：未確認','Exact collapse coordinates and current safety: not verified')}</p><button class="text-button" data-view="audit">${t('照合方法と未確認項目を見る','View audit method and unchecked fields')} →</button></section>`;
}
function auditRecords(){return filtered.filter(r=>auditQueue==='notes'?auditIssues(r).length:auditQueue==='unlocated'?!mapped(r):auditQueue==='missing'?!num(r.depthM):r.timeline);}
function renderAudit(){
 const pane=$('#pane-audit');if(!auditData){pane.innerHTML='<div class="empty">'+t('照合レポートを読み込めませんでした。確認済みとは表示できません。','The audit report is unavailable. No verified status can be shown.')+'</div>';return;}
 const summary=auditData.summary,queue=auditRecords(),hashOK=auditData.files.every(f=>datasetIntegrity[f.datasetFile]==='match');
 pane.innerHTML=`<div class="section-heading"><div><p class="eyebrow">EVIDENCE, NOT ASSUMPTION</p><h3>${t('公開前に、根拠と未確認を分ける。','Separate evidence from what remains unchecked.')}</h3><p>${t('元資料との照合結果と、確認が必要な記録をたどれます。','Inspect the source comparison and records that need review.')}</p></div><div class="download-actions"><button id="recheck-data" class="button-outline" ${auditBusy?'disabled':''}>${auditBusy?t('検査中…','Checking…'):t('配信データを再検査','Recheck delivered files')}</button><button id="export-audit" class="button-outline">${t('照合レポートを保存','Export audit report')} ↓</button></div></div>
 <div class="audit-banner"><b>${t('転記の一致と、事実の正しさは別の確認です。','A matching transcription is not proof of real-world accuracy.')}</b><p>${t('この機能は保存済み原Excelと掲載値を照合し、欠測・矛盾・未確認を可視化します。事故の正確な地点、原資料の記載自体、最新の復旧状況を自動認定するものではありません。','This feature compares published values with retained XLSX sources and exposes gaps, conflicts and unverified items. It does not certify exact incident locations, the accuracy of source statements or the latest recovery status.')}</p></div>
 <div class="audit-metrics"><div><b>${fmt(summary.checkedRecords)}</b><span>${t('原Excelと照合した全国記録','National records compared')}</span></div><div><b>${fmt(summary.mismatchedRecords)}</b><span>${t('転記の不一致','Transcription mismatches')}</span></div><div><b>${fmt(summary.issueRecords)}</b><span>${t('注記のある全国記録','National records with notes')}</span></div></div>
 <p class="${hashOK?'audit-ok':'audit-warning'}">${hashOK?t('配信中の3データファイルは、照合済みファイルとハッシュが一致しています。','All three delivered data files match the audited file hashes.'):t('配信ファイルの一致を確認できていません。「配信データを再検査」で確認してください。','Delivered-file integrity is not verified. Run the file recheck.')}</p>
 ${runtimeCheck?'<p>'+t('ブラウザー内の構造検査：','In-browser structural check: ')+fmt(runtimeCheck.records)+t('件、エラー ',' records; errors ')+runtimeCheck.errors.length+' / '+esc(runtimeCheck.checkedAt)+'</p>':''}
 <h4>${t('確認が必要な記録','Review queue')}</h4><div class="audit-queue-controls"><select id="audit-queue" aria-label="${t('確認項目','Review category')}"><option value="notes">${t('資料の矛盾・補完・規模差の注記','Source conflicts / inferred values / size context')}</option><option value="unlocated">${t('場所が不明','Unlocated records')}</option><option value="missing">${t('深さが未記載','Depth not reported')}</option><option value="cases">${t('個別資料の再照合が未実施','Case documents not re-audited')}</option></select><span>${t('現在の検索条件で ','Current filters: ')}${fmt(queue.length)} ${t('件','records')}</span></div>
 <div class="audit-queue">${queue.length?queue.slice(0,auditLimit).map(r=>'<article class="audit-item"><button data-record="'+esc(r.id)+'">'+esc(prefLabel(r.prefecture))+' · '+esc(recordTitle(r))+' →</button><small>'+esc(r.id)+'</small>'+ (auditQueue==='notes'?auditIssues(r).map(i=>'<p>'+esc(issueText(i))+'</p>').join(''):'<p>'+esc(auditQueue==='unlocated'?t('住所照合ができず、地図に表示していません。','Address unresolved; omitted from the map.'):auditQueue==='missing'?t('原資料に数値の深さがなく、深さ条件の検索から除外されます。','No numeric depth in the source; excluded by depth thresholds.'):t('個別資料に基づく要約・年表。今回のExcel照合の対象外です。','Narrative and timeline from individual sources; outside the XLSX audit.'))+'</p>')+'</article>').join(''):'<p>'+t('この条件に該当する記録はありません。','No records in this category under the current filters.')+'</p>'}</div>${queue.length>auditLimit?'<button id="audit-more" class="load-more">'+t('続きを表示','Show more')+'</button>':''}
 <h4>${t('照合方法と対象','Method and coverage')}</h4><p>${esc(auditData.method[lang])}</p><p>${t('照合日時：','Audit timestamp: ')}${esc(auditData.checkedAt)} · ${fmt(summary.checkedFieldValues)} ${t('項目','field values')}</p>
 <div class="source-cards">${auditData.files.map(f=>'<div class="source-card"><b>FY '+f.fiscalYear+' · '+fmt(f.recordCount)+' '+t('件','records')+'</b>'+sourceLink(f.url,t('照合元の国交省Excel','MLIT XLSX source'))+'<small class="hash">SHA-256: '+f.sha256+'</small><p>'+t('確認項目：住所・路線・管理者・要因・寸法原表記・数値変換・年度・出典URL','Checked: address, road, manager, cause, raw and numeric dimensions, fiscal year and source URLs')+'</p></div>').join('')}</div>
 <h4>${t('都道府県別の公式集計との照合','Comparison with official prefecture totals')}</h4><p>${t('2024・2025年度は47都道府県すべて一致。2023年度は、管理者「島根県」と住所「岡山県」が食い違う原票1行により、島根が1件少なく、岡山が1件多くなります。全国総数は一致しています。','FY 2024 and 2025 match all 47 prefectures. In FY 2023, one source row conflicts between a Shimane manager and an Okayama address, producing −1 for Shimane and +1 for Okayama. The national total matches.')}</p>
 <h4>${t('この検査で確認していないこと','Not established by this audit')}</h4><ul>${auditData.coverage[lang==='en'?'notCheckedEn':'notCheckedJa'].map(s=>'<li>'+esc(s)+'</li>').join('')}</ul><p>${esc(auditData.coverage[lang==='en'?'rawSourceSnapshotPolicyEn':'rawSourceSnapshotPolicyJa'])}</p>
 <p>${t('「配信データを再検査」はファイルの一致と構造を確認します。国交省サイトの最新版を自動取得して内容を再調査する処理ではありません。外部公開前には、注記の解消・出典の更新・個別資料の人による確認を行ってください。','The recheck verifies delivered-file hashes and structure. It does not fetch and re-investigate the latest MLIT publications. Before public release, resolve review notes, update sources and review individual case documents.')}</p>`;
 $('#audit-queue').value=auditQueue;$('#audit-queue').onchange=()=>{auditQueue=$('#audit-queue').value;auditLimit=40;renderAudit();};$('#audit-more')?.addEventListener('click',()=>{auditLimit+=40;renderAudit();});
 $('#export-audit').onclick=()=>downloadFile(JSON.stringify({sourceAudit:auditData,browserCheck:runtimeCheck,datasetIntegrity},null,2),'sinkhole-atlas-source-audit.json','application/json');
 $('#recheck-data').onclick=async()=>{auditBusy=true;renderAudit();try{for(const f of auditData.files){await fetchRecords(f.datasetFile);}runtimeCheck=runStructuralChecks();toast(t('配信ファイルと構造の検査が完了しました','File and structure checks completed'));}catch(error){toast(t('再検査できませんでした：','Recheck failed: ')+error.message);}finally{auditBusy=false;renderAudit();if(selected)openDetail(selected,false,false);}};
}

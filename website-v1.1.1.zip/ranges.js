'use strict';
const depthChoices=[.2,.5,1,2,3,5,10,15];
function rangeLimits(kind){
 const values=(kind==='year'?national.map(r=>r.fiscalYear):all().map(r=>r.depthM)).filter(num);
 return kind==='year'?[Math.min(...values),Math.max(...values)]:[0,Math.max(1,...values)];
}
function selectedBound(kind,side){const value=$('#'+kind+'-'+side).value;return value===''?(side==='min'?-Infinity:Infinity):Number(value);}
function resetRangeFilters(){
 for(const kind of ['year','depth'])for(const side of ['min','max'])$('#'+kind+'-'+side).value='';
 $('#depth-missing').value='include';updateRangeUI();
}
function yearRangeLabel(){
 const [first,last]=rangeLimits('year'),min=$('#year-min').value||first,max=$('#year-max').value||last;
 return t(min+(String(min)===String(max)?'':'–'+max)+'年度','FY '+min+(String(min)===String(max)?'':'–'+max));
}
function updateRangeUI(){
 $('#year-filter').disabled=scope==='featured';
 $('#year-summary').textContent=scope==='featured'?t('全国調査のみ','National survey only'):yearRangeLabel();
 $('#depth-values').disabled=$('#depth-missing').value==='only';
 const dmin=$('#depth-min').value,dmax=$('#depth-max').value;
 $('#depth-summary').textContent=$('#depth-missing').value==='only'?t('未記載のみ','Not reported only'):!dmin&&!dmax?t('すべて','All'):dmin&&dmax?dmin+'–'+dmax+' m':dmin?dmin+' m '+t('以上','or deeper'):dmax+' m '+t('以下','or shallower');
 for(const kind of ['year','depth'])for(const side of ['min','max']){
  const el=$('#'+kind+'-'+side),previous=el.value,values=kind==='year'?[...new Set(national.map(r=>r.fiscalYear))].sort():depthChoices;
  const label=kind==='year'?(v=>t(v+'年度','FY '+v)):(v=>v<1?fmt(v*100)+' cm':fmt(v)+' m');
  el.innerHTML='<option value="">'+t('指定なし','Any')+'</option>'+values.map(v=>'<option value="'+v+'">'+label(v)+'</option>').join('');
  el.value=previous;
  el.setAttribute('aria-label',t((kind==='year'?'対象年度':'陥没の深さ')+'（'+(kind==='year'?(side==='min'?'から':'まで'):(side==='min'?'以上':'以下'))+'）',(kind==='year'?'Fiscal year':'Depth')+' '+(side==='min'?'minimum':'maximum')));
 }
}
function updateRangeControl(kind,side,raw){
 const value=String(raw),valid=kind==='year'?[...new Set(national.map(r=>r.fiscalYear))]:depthChoices;
 if(value!==''&&!valid.includes(Number(value)))return false;
 const other=side==='min'?'max':'min';$('#'+kind+'-'+side).value=value;
 if(selectedBound(kind,'min')>selectedBound(kind,'max'))$('#'+kind+'-'+other).value=value;
 if(kind==='depth')$('#depth-missing').value=$('#depth-min').value||$('#depth-max').value?'exclude':'include';
 updateRangeUI();return true;
}
function wireRangeFilters(){
 const refresh=()=>{pointFilter=null;meshFilter=null;applyFilters();};
 for(const kind of ['year','depth'])for(const side of ['min','max']){
  const select=$('#'+kind+'-'+side);
  select.onchange=()=>{updateRangeControl(kind,side,select.value);refresh();};
 }
 $('#depth-missing').onchange=()=>{updateRangeUI();refresh();};
}

'use strict';
// National records only specify a fiscal year. Never infer a month or event date.
const playback = {active:false,playing:false,index:0,mode:'period',delay:2000,timer:null,frames:[],records:[],signature:'',scaleCache:new Map(),ready:false};
function playbackKey(record,dataset){
 if(dataset==='national')return Number.isInteger(record.fiscalYear)?String(record.fiscalYear):null;
 const date=record.date;
 return typeof date==='string'&&/^\d{4}-\d{2}-\d{2}$/.test(date)&&!Number.isNaN(Date.parse(date))&&new Date(date).toISOString().slice(0,10)===date?date:null;
}
function buildPlaybackFrames(records,dataset,years=[]){
 const groups=new Map(years.map(year=>[String(year),[]]));
 for(const record of records){const key=playbackKey(record,dataset);if(key===null)continue;if(!groups.has(key))groups.set(key,[]);groups.get(key).push(record);}
 return [...groups].sort(([a],[b])=>a.localeCompare(b)).map(([key,records])=>({key,records}));
}
function recordsAtFrame(frames,index,cumulative){return cumulative?frames.slice(0,index+1).flatMap(frame=>frame.records):(frames[index]?.records||[]);}
function playbackPeriodLabel(key){return scope==='national'?t(key+'年度','FY '+key):key.replaceAll('-','.');}
function pausePlayback(){clearTimeout(playback.timer);playback.timer=null;playback.playing=false;if(playback.ready)renderPlaybackUI();}
function syncPlaybackRecords(records){
 const years=scope==='national'?[...new Set(national.map(r=>r.fiscalYear))].filter(year=>year>=selectedBound('year','min')&&year<=selectedBound('year','max')).sort():[];
 const signature=scope+'|'+years.join(',')+'|'+records.map(r=>r.id).sort().join(',');
 if(signature!==playback.signature){
  clearTimeout(playback.timer);playback.timer=null;playback.playing=false;playback.active=false;playback.index=0;
  playback.signature=signature;playback.scaleCache.clear();
 }
 playback.records=records;playback.frames=buildPlaybackFrames(records,scope,years);
 if(playback.index>=playback.frames.length)playback.index=0;
 const result=playback.active?recordsAtFrame(playback.frames,playback.index,playback.mode==='cumulative'):records;
 if(playback.ready)renderPlaybackUI();
 return result;
}
function playbackScaleCells(km){
 if(!playback.active)return null;
 const key=km+'|'+playback.mode;
 if(!playback.scaleCache.has(key)){
  const cells=new Map();
  const batches=playback.mode==='cumulative'?[playback.frames.flatMap(frame=>frame.records)]:playback.frames.map(frame=>frame.records);
  for(const records of batches)for(const [cell,rs] of aggregateGrid(records,km))if(!cells.has(cell)||cells.get(cell).length<rs.length)cells.set(cell,rs);
  playback.scaleCache.set(key,cells);
 }
 return playback.scaleCache.get(key);
}
function queuePlayback(){
 clearTimeout(playback.timer);
 if(!playback.playing)return;
 playback.timer=setTimeout(()=>{
  if(!playback.playing)return;
  if(playback.index>=playback.frames.length-1){pausePlayback();return;}
  playback.index++;filterRecords();
  if(playback.index>=playback.frames.length-1)pausePlayback();else queuePlayback();
 },playback.delay);
}
function seekPlayback(index){
 pausePlayback();if(!playback.frames.length)return;
 playback.index=Math.max(0,Math.min(playback.frames.length-1,index));playback.active=true;
 closeDetail();filterRecords();
}
function togglePlayback(){
 if(playback.playing){pausePlayback();return;}
 if(!playback.frames.some(frame=>frame.records.length))return;
 closeDetail();closeMobilePanels();
 if(!playback.active||playback.index===playback.frames.length-1)playback.index=0;
 playback.active=true;playback.playing=playback.frames.length>1;filterRecords();queuePlayback();
}
function clearPlayback(){pausePlayback();playback.active=false;playback.index=0;filterRecords();}
function renderPlaybackUI(){
 if(!playback.ready)return;
 $('#playback-panel').hidden=view!=='map';
 const frames=playback.frames,frame=frames[playback.index],hasRecords=frames.some(f=>f.records.length),active=playback.active;
 const shown=active?recordsAtFrame(frames,playback.index,playback.mode==='cumulative'):playback.records;
 const dated=frames.reduce((sum,f)=>sum+f.records.length,0),unknown=playback.records.length-dated;
 const period=frame?playbackPeriodLabel(frame.key):'';
 $('#playback-title').textContent=t('時系列で見る','Explore over time');
 $('#playback-play').textContent=playback.playing?t('Ⅱ 一時停止','Ⅱ Pause'):active&&playback.index===frames.length-1?t('↻ もう一度','↻ Replay'):t('▶ 再生','▶ Play');
 $('#playback-play').disabled=!map||!hasRecords;
 $('#playback-play').setAttribute('aria-pressed',String(playback.playing));
 $('#playback-all').textContent=t('全期間に戻す','Show all periods');$('#playback-all').disabled=!active;
 $('#playback-period-label').textContent=t('表示する時点','Period');
 $('#playback-period').innerHTML=frames.map((f,i)=>'<option value="'+i+'">'+esc(playbackPeriodLabel(f.key))+' · '+fmt(f.records.length)+t('件',' records')+'</option>').join('');
 $('#playback-period').value=String(playback.index);$('#playback-period').disabled=!hasRecords;
 $('#playback-prev').disabled=!hasRecords||playback.index===0;$('#playback-next').disabled=!hasRecords||playback.index>=frames.length-1;
 $('#playback-prev').setAttribute('aria-label',t('前の時点','Previous period'));$('#playback-next').setAttribute('aria-label',t('次の時点','Next period'));
 $('#playback-mode-label').textContent=t('表示範囲','Display');
 $('#playback-mode').options[0].textContent=t('その期間のみ','Current period');$('#playback-mode').options[1].textContent=t('開始から累積','Cumulative');
 $('#playback-speed-label').textContent=t('切り替え間隔','Step interval');
 for(const option of $('#playback-speed').options)option.textContent=(Number(option.value)/1000)+t('秒',' s');
 $('#playback-controls').hidden=!active;
 $('#playback-panel').classList.toggle('is-active',active);
 const state=playback.playing?t('再生中','Playing'):active?t('停止中','Paused'):t('全期間を表示中','All periods');
 const range=active&&playback.mode==='cumulative'&&playback.index>0&&frames.length?playbackPeriodLabel(frames[0].key)+' → '+period:period;
 $('#playback-status').textContent=active?range+' · '+state+' ／ '+fmt(shown.length)+t('件（地図 ',' records (mapped ')+fmt(shown.filter(mapped).length)+t('件）',')'):hasRecords?t('現在の条件で '+fmt(frames.length)+' 時点を順番に表示します。','Play '+fmt(frames.length)+' periods with the current filters.'):t('再生できる記録がありません。','No records available for playback.');
 $('#playback-note').textContent=(scope==='national'?t('全国調査は年度別です。発生日が未公表のため、月・日ごとの再生はできません。','National records are grouped by fiscal year; event dates are not published.'):t('選定事例を発生日順に表示します。全国の発生件数を網羅したものではありません。','Selected cases are shown by event date; they do not represent all incidents.'))
 +(unknown?t(' 時期不明の '+fmt(unknown)+' 件は再生対象外です。',' '+fmt(unknown)+' undated records are excluded from playback.'):'')
 +(active?t(' 色尺度は再生対象の全期間で共通です。絞り込みを変更すると全期間表示に戻ります。',' The color scale is shared across playback periods. Changing filters returns to all periods.'):'');
 $('#playback-summary').textContent=active&&frame?t('この時点の新規：'+fmt(frame.records.length)+'件','New in this period: '+fmt(frame.records.length)):t('県・深さなどの絞り込み条件を反映','Uses your location, depth and other filters');
}
function wirePlayback(){
 playback.ready=true;
 $('#playback-play').onclick=togglePlayback;$('#playback-all').onclick=clearPlayback;
 $('#playback-prev').onclick=()=>seekPlayback(playback.index-1);$('#playback-next').onclick=()=>seekPlayback(playback.index+1);
 $('#playback-period').onchange=()=>seekPlayback(Number($('#playback-period').value));
 $('#playback-mode').onchange=()=>{pausePlayback();playback.mode=$('#playback-mode').value;manualGridLimits=null;filterRecords();};
 $('#playback-speed').onchange=()=>{playback.delay=Number($('#playback-speed').value);queuePlayback();};
 document.addEventListener('visibilitychange',()=>{if(document.hidden)pausePlayback();});
 if(typeof ResizeObserver!=='undefined')new ResizeObserver(()=>map?.invalidateSize({animate:false})).observe($('#map'));
 renderPlaybackUI();
}

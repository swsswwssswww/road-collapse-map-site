'use strict';
// One navigation stack for the desktop sidebar and the in-flow mobile panel.
let browseSnapshot=null, candidateState=null, navigationMoving=false, touchGesture=false, lastGesture=0;
function saveBrowsePosition(){
 if(browseSnapshot)return;
 browseSnapshot={scroll:$('.sidebar').scrollTop,windowY:window.scrollY,center:map?.getCenter(),zoom:map?.getZoom(),focus:document.activeElement,sidebarOpen:typeof sidebarOpen!=='undefined'?sidebarOpen:true};
}
function updatePanel(){
 const detailOpen=!$('#detail').hidden;
 $('#browse-panel').hidden=detailOpen||!!candidateState;
 $('#candidate-panel').hidden=detailOpen||!candidateState;
 $('.sidebar').classList.toggle('showing-detail',detailOpen);
 if(typeof syncSidebar==='function')syncSidebar();
}
function focusPanel(){
 $('.sidebar').scrollTop=0;
 if(typeof setSidebarOpen==='function')setSidebarOpen(true);
}
function restoreBrowsePosition(){
 const saved=browseSnapshot;browseSnapshot=null;
 if(!saved)return;
 if(typeof setSidebarOpen==='function')setSidebarOpen(saved.sidebarOpen);
 navigationMoving=true;
 if(map&&saved.center)map.setView(saved.center,saved.zoom,{animate:false});
 navigationMoving=false;
 requestAnimationFrame(()=>{ $('.sidebar').scrollTop=saved.scroll;if(mobileMedia.matches)window.scrollTo({top:saved.windowY});saved.focus?.isConnected&&saved.focus.focus({preventScroll:true}); });
}
function openCandidates(records,heading){
 if(!records.length||!tapAllowed())return;
 pausePlayback();clearMapSummary();saveBrowsePosition();
 selected=null;$('#detail').hidden=true;showSelectedPoint();history.replaceState(null,'',location.pathname+location.search);
 candidateState={records,heading,limit:40,scroll:0,windowY:window.scrollY,center:map?.getCenter(),zoom:map?.getZoom()};renderCandidates();updatePanel();focusPanel();$('#candidate-back').focus({preventScroll:true});
}
function renderCandidates(){
 if(!candidateState)return;
 const c=candidateState;
 $('#candidate-panel').innerHTML='<button id="candidate-back" class="back-button">← '+t('地図設定に戻る','Back to map settings')+'</button><h2>'+esc(t('選択した範囲の候補','Records in the selected area'))+'</h2><p>'+fmt(c.records.length)+t('件。記録を選んで詳細を開きます。',' records. Select a record for details.')+'</p>'+c.records.slice(0,c.limit).map(r=>'<button class="result-item" data-record="'+esc(r.id)+'"><h3>'+esc(recordTitle(r))+'</h3><p>'+esc(dateLabel(r))+' · '+esc(r.address)+'</p><span>'+t('深さ','Depth')+' '+dim(r.depthM)+' m</span></button>').join('')+(c.limit<c.records.length?'<button id="candidate-more">'+t('続きを表示','Show more')+'</button>':'');
 $('#candidate-back').onclick=()=>{candidateState=null;updatePanel();restoreBrowsePosition();};
 $('#candidate-more')?.addEventListener('click',()=>{c.limit+=40;const s=$('.sidebar').scrollTop;renderCandidates();$('.sidebar').scrollTop=s;});
}
function clearMapSummary(){const el=$('#map-summary');if(el)el.hidden=true;}
function bindMapSummary(layer,content){
 layer.on('mouseover',e=>{
  if(!matchMedia('(hover:hover) and (pointer:fine)').matches||touchGesture||e.originalEvent?.sourceCapabilities?.firesTouchEvents)return;
  const el=$('#map-summary');el.innerHTML=content;el.hidden=false;
 });
 layer.on('mouseout',clearMapSummary);
}
function tapAllowed(){return !touchGesture&&performance.now()-lastGesture>250;}
function wireMapGestures(){
 const pointers=new Map();let moved=false;
 const container=map.getContainer();
 container.addEventListener('pointerdown',e=>{clearMapSummary();pointers.set(e.pointerId,[e.clientX,e.clientY]);if(pointers.size===1)moved=false;if(pointers.size>1)moved=true;touchGesture=moved;},{passive:true});
 container.addEventListener('pointermove',e=>{const start=pointers.get(e.pointerId);if(start&&Math.hypot(e.clientX-start[0],e.clientY-start[1])>10){moved=true;touchGesture=true;}},{passive:true});
 const end=e=>{if(!pointers.has(e.pointerId))return;if(moved)lastGesture=performance.now();pointers.delete(e.pointerId);if(!pointers.size)touchGesture=false;};
 window.addEventListener('pointerup',end,{passive:true});window.addEventListener('pointercancel',end,{passive:true});
 map.on('dragstart zoomstart',()=>{lastGesture=performance.now();clearMapSummary();});
 map.on('dragend zoomend',()=>{lastGesture=performance.now();});
 map.on('movestart',clearMapSummary);
}

function clearRecordNavigation(){const wasNavigating=selected||candidateState;candidateState=null;browseSnapshot=null;selected=null;$('#detail').hidden=true;showSelectedPoint();updatePanel();if(wasNavigating)history.replaceState(null,'',location.pathname+location.search);}

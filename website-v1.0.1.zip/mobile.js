'use strict';
// Shared controls move into native modal sheets on compact screens.
// Their values and listeners stay intact when the viewport changes.
const mobileMedia = window.matchMedia('(max-width: 900px)');
let mobileReady = false, mobileSheetMode = 'filters';
const mobileHomes = new Map();
function closeMobilePanels(restoreFocus = false) {
  if (!mobileReady) return;
  for (const id of ['mobile-panel', 'mobile-settings']) {
    const dialog = document.getElementById(id);
    if (dialog.open) dialog.close();
  }
  document.querySelector('.sidebar').classList.remove('open');
  if (restoreFocus) document.getElementById('mobile-filters').focus();
}
function openMobilePanel(panel) {
  if (!mobileReady || !mobileMedia.matches) return;
  closeDetail();
  closeMobilePanels();
  if (panel === 'settings') {
    document.getElementById('mobile-settings').showModal();
    return;
  }
  mobileSheetMode = panel;
  const dialog = document.getElementById('mobile-panel');
  dialog.dataset.mode = panel;
  updateMobileUI();
  dialog.showModal();
}
function syncMobileDetail() {
  if (!mobileReady) return;
  const detail = document.getElementById('detail');
  const modal = mobileMedia.matches && !detail.hidden;
  for (const selector of ['.header', '.app-shell', '.mobile-actions']) {
    document.querySelector(selector).inert = modal;
  }
  if (modal) {
    detail.setAttribute('role', 'dialog');
    detail.setAttribute('aria-modal', 'true');
  } else {
    detail.removeAttribute('role');
    detail.removeAttribute('aria-modal');
  }
}
function updateMobileUI() {
  if (!mobileReady) return;
  const set = (id, ja, en) => document.getElementById(id).textContent = t(ja, en);
  set('mobile-map', '地図', 'Map');
  set('mobile-filters', '絞り込み', 'Filters');
  set('mobile-results-label', '検索結果', 'Results');
  set('mobile-result-count', fmt(filtered.length) + '件', fmt(filtered.length));
  set('mobile-panel-title', mobileSheetMode === 'filters' ? '検索・絞り込み' : '検索結果', mobileSheetMode === 'filters' ? 'Search & filters' : 'Matching records');
  set('mobile-tab-filters', '絞り込み', 'Filters');
  set('mobile-tab-results', '検索結果', 'Results');
  set('mobile-apply', fmt(filtered.length) + '件を地図で見る', 'Show ' + fmt(filtered.length) + ' on map');
  set('mobile-settings-title', '地図の表示設定', 'Map display settings');
  set('mobile-settings-done', '地図に戻る', 'Back to map');
  set('mobile-disclaimer', '住所の代表位置を表示しています。危険度を示す地図ではありません。', 'Representative locations, not exact incident points or a hazard map.');
  document.querySelectorAll('.sheet-close').forEach(b => b.setAttribute('aria-label', t('閉じる', 'Close')));
  for (const key of ['filters', 'results']) document.getElementById('mobile-tab-' + key).setAttribute('aria-pressed', String(mobileSheetMode === key));
  const filtersActive = ['search','pref','cause','precision','year-min','year-max','depth-min','depth-max'].some(id => document.getElementById(id).value) || document.getElementById('depth-missing').value !== 'include' || document.getElementById('in-bounds').checked || meshFilter || pointFilter || scope !== 'national';
  document.getElementById('mobile-filters').classList.toggle('has-filters', !!filtersActive);
  document.getElementById('mobile-map').setAttribute('aria-pressed', String(view === 'map'));
  document.getElementById('mobile-disclaimer').hidden = view !== 'map';
  const toggle = document.getElementById('mobile-settings-toggle');
  const scale = mode === 'density' && currentGridCells ? buildGridScale(currentGridCells, manualGridLimits) : null;
  toggle.innerHTML = scale ? '<span class="mobile-scale-heading">' + esc(t('約' + currentGridKm + ' kmメッシュ', currentGridKm + ' km grid')) + '<b>' + esc(t('色・集計の設定', 'Adjust display')) + ' ↑</b></span><span class="mobile-scale-line"><span>' + fmt(scale.lower) + '</span><i style="background:' + scale.gradient + '"></i><span>' + (scale.max ? fmt(scale.upper) : '0') + esc(t('件', ' records')) + '</span></span>' : '<span class="mobile-scale-heading">' + esc(t('原因別の色分け', 'Colors by cause')) + '<b>' + esc(t('凡例を見る', 'View legend')) + ' ↑</b></span>';
  toggle.setAttribute('aria-label', t('地図の表示設定を開く', 'Open map display settings'));
  const labels = { map:['地図','Map'],table:['データ一覧','Records'],stats:['分布','Patterns'],sources:['データについて','About'],audit:['出典照合','Checks'] };
  if (mobileMedia.matches) document.querySelectorAll('.header .nav').forEach(b => b.textContent = t(...labels[b.dataset.view]));
  syncMobileDetail();
}
function wireMobileUI() {
  if (mobileReady) return;
  mobileReady = true;
  const sidebar = document.querySelector('.sidebar');
  for (const node of [sidebar, ...['density-options','legend','map-notice'].map(id => document.getElementById(id))]) {
    const anchor = document.createComment('desktop control position');
    node.before(anchor); mobileHomes.set(node, anchor);
  }
  const applyLayout = () => {
    closeMobilePanels();
    if (mobileMedia.matches) {
      document.getElementById('mobile-panel-body').append(sidebar);
      const settings = document.getElementById('mobile-settings-body');
      for (const id of ['density-options','legend','map-notice']) settings.append(document.getElementById(id));
    } else {
      for (const [node, anchor] of mobileHomes) anchor.after(node);
      const labels = {map:['地図で探す','Explore map'],table:['データ一覧','Records'],stats:['分布を読む','Patterns'],sources:['データについて','About the data'],audit:['出典照合','Source checks']};
      document.querySelectorAll('.header .nav').forEach(b => b.textContent = t(...labels[b.dataset.view]));
    }
    updateMobileUI();
    requestAnimationFrame(() => map?.invalidateSize());
  };
  mobileMedia.addEventListener('change', applyLayout);
  for (const key of ['filters','results']) {
    document.getElementById('mobile-' + key).onclick = () => openMobilePanel(key);
    document.getElementById('mobile-tab-' + key).onclick = () => {
      mobileSheetMode = key;
      document.getElementById('mobile-panel').dataset.mode = key;
      updateMobileUI();
    };
  }
  document.getElementById('mobile-map').onclick = () => { closeDetail(); setView('map'); };
  document.getElementById('toggle-sidebar').onclick = () => openMobilePanel('filters');
  document.getElementById('mobile-settings-toggle').onclick = () => openMobilePanel('settings');
  document.getElementById('mobile-apply').onclick = () => { closeMobilePanels(); setView('map'); };
  document.getElementById('mobile-settings-done').onclick = () => closeMobilePanels();
  for (const dialog of document.querySelectorAll('.mobile-sheet')) {
    dialog.querySelector('.sheet-close').onclick = () => dialog.close();
    dialog.addEventListener('click', event => {
      if (event.target !== dialog) return;
      const r = dialog.getBoundingClientRect();
      if (event.clientX < r.left || event.clientX > r.right || event.clientY < r.top || event.clientY > r.bottom) dialog.close();
    });
  }
  // Keep keyboard focus inside the full-screen record on compact screens.
  document.addEventListener('keydown', event => {
    const detail = document.getElementById('detail');
    if (!mobileMedia.matches || detail.hidden || event.key !== 'Tab') return;
    const items = [...detail.querySelectorAll('a[href],button:not([disabled]),input,select,[tabindex="0"]')].filter(el => el.getClientRects().length);
    const first = items[0], last = items[items.length - 1];
    if (event.shiftKey && (document.activeElement === first || !detail.contains(document.activeElement))) { event.preventDefault(); last?.focus(); }
    else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first?.focus(); }
  });
  applyLayout();
}

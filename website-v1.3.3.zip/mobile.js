'use strict';
// One sidebar and one map at every viewport size; no DOM relocation on resize.
const mobileMedia=matchMedia('(max-width: 900px)');
let mobileReady=false,sidebarOpen=!mobileMedia.matches;
function syncSidebar(){
 if(!mobileReady)return;
 const detailOpen=!$('#detail').hidden||!!candidateState;
 $('.sidebar').hidden=!sidebarOpen;
 document.body.classList.toggle('sidebar-collapsed',!sidebarOpen);
 document.body.classList.toggle('map-active',view==='map');
 $('#toggle-sidebar').textContent=sidebarOpen?t('☰ 設定を閉じる','☰ Hide settings'):t('☰ 設定を開く','☰ Show settings');
 $('#toggle-sidebar').setAttribute('aria-expanded',String(sidebarOpen));
 $('#sidebar-title').textContent=detailOpen?t('選択した記録','Selected records'):t('検索・地図設定','Search & map settings');
 $('#sidebar-close').textContent=t('閉じる ×','Close ×');
 $('#sidebar-close').setAttribute('aria-label',t('サイドバーを閉じる','Close sidebar'));
 $('#terrain-tools').hidden=view!=='map';$('#display-settings').hidden=view!=='map';
 const attribution=$('.attribution-footer');if(attribution)attribution.hidden=view!=='map';
}
function setSidebarOpen(open,focus=false){
 sidebarOpen=open;syncSidebar();
 requestAnimationFrame(()=>{map?.invalidateSize({animate:false});if(focus)(open?$('#sidebar-close'):$('#toggle-sidebar')).focus({preventScroll:true});});
}
function closeMobilePanels(){if(mobileReady&&mobileMedia.matches)setSidebarOpen(false);}
function openMobilePanel(){setSidebarOpen(true,true);}
function syncMobileDetail(){updatePanel();}
function updateMobileUI(){
 if(!mobileReady)return;
 const labels={map:['地図','Map'],table:['データ一覧','Records'],stats:['分布','Patterns'],sources:['データについて','About'],audit:['出典照合','Checks']};
 $$('.header .nav').forEach(b=>b.textContent=t(...labels[b.dataset.view]));
 $('#display-settings-summary').textContent=t('地図の表示・色分け','Map display & colors');
 syncSidebar();if(typeof updateTerrainUI==='function')updateTerrainUI();
}
function wireMobileUI(){
 if(mobileReady)return;mobileReady=true;
 $('#toggle-sidebar').onclick=()=>setSidebarOpen(!sidebarOpen,true);
 $('#sidebar-close').onclick=()=>setSidebarOpen(false,true);
 document.addEventListener('keydown',e=>{if(e.key==='Escape')setSidebarOpen(false,true);});
 mobileMedia.addEventListener('change',()=>setSidebarOpen(!mobileMedia.matches));
 if(typeof ResizeObserver!=='undefined')new ResizeObserver(()=>{if(view==='map')map?.invalidateSize({animate:false});}).observe($('#map'));
 syncSidebar();requestAnimationFrame(()=>{map?.invalidateSize({animate:false});fitJapan();});
}

'use strict';
const terrain={base:'pale',compare:false,region:'tokyo50',period:0,opacity:50,historyLayer:null,coverage:null,ready:false,errors:new Set()};
const baseMaps={
 pale:{ja:'淡色地図',en:'Pale map',tile:'pale',min:2,max:18},
 std:{ja:'標準地図（地名を読みやすく）',en:'Standard map (clear labels)',tile:'std',min:2,max:18},
 photo:{ja:'航空写真（広域は衛星画像）',en:'Aerial / satellite imagery',tile:'seamlessphoto',ext:'jpg',min:2,max:18},
 hill:{ja:'陰影起伏図（DEM）',en:'Hillshade (DEM)',tile:'hillshademap',min:2,max:16},
 relief:{ja:'標高段彩図（DEM・陰影付き）',en:'Elevation colors with shading (DEM)',tile:'relief',min:5,max:15},
 historical:{ja:'古地図・旧版地形図',en:'Historical topographic map'}
};
function historyRegion(){return historicalCatalog.find(r=>r.id===terrain.region)||historicalCatalog[0];}
function historyPeriod(){return historyRegion().periods[terrain.period]||historyRegion().periods[0];}
function historyVisible(){return terrain.base==='historical'||terrain.compare;}
function sheetContains(sheet,lat,lon){const [s,w,n,e]=sheet.bounds;return lat>=s&&lat<=n&&lon>=w&&lon<=e;}
function initTerrain(){
 if(!map)return;
 map.createPane('historicalMap').style.zIndex='250';
 map.createPane('historicalCoverage').style.zIndex='410';map.getPane('historicalCoverage').style.pointerEvents='none';terrain.coverageRenderer=L.canvas({pane:'historicalCoverage'});
 $('#terrain-body').innerHTML=`
 <label><span data-ja="背景地図" data-en="Base map"></span><select id="basemap"></select></label>
 <label class="checkbox"><input type="checkbox" id="compare-history"><span data-ja="古地図を透過して比較する" data-en="Overlay a historical map"></span></label>
 <section id="history-options" hidden>
 <div class="terrain-fields"><label><span data-ja="古地図の地域" data-en="Historical map region"></span><select id="history-region"></select></label><label><span id="history-date-caption">収録年代</span><select id="history-period"></select></label></div>
 <button id="history-nearby" data-ja="この場所の古地図を探す" data-en="Find historical maps here"></button><div id="history-matches" aria-live="polite"></div>
 <button id="history-jump" data-ja="この地域を表示" data-en="Go to this region"></button>
 <label><span data-ja="古地図の不透明度（0%＝現在、100%＝古地図）" data-en="Historical opacity (0% current, 100% historical)"></span><input type="range" id="history-opacity" min="0" max="100" step="5" value="50"><output id="history-opacity-value">50%</output></label>
 <label class="checkbox"><input id="history-coverage" type="checkbox" checked><span data-ja="収録図幅を青い破線で表示" data-en="Show map sheets as blue dashed outlines"></span></label>
 <p id="history-meta"></p><p id="history-center" role="status"></p>
 <p class="comparison-warning" data-ja="比較閲覧専用：等高線の違いだけで切土・盛土とは断定できません。位置合わせ・標高基準・解像度・測量時期・誤差を検証していないため、標高差の算出と切土・盛土の自動判定は未対応です。" data-en="Visual comparison only. Contour differences do not establish cut or fill. Registration, vertical datum, resolution, survey dates and errors have not been validated. Elevation differences and automatic cut/fill classification are not supported."></p>
 <details><summary data-ja="比較の見方・資料を確認" data-en="How to compare and check sources"></summary>
 <ol><li data-ja="道路・河川などの変わりにくい目印で位置のずれを確認します。" data-en="Check alignment against stable roads, rivers and other landmarks."></li><li data-ja="等高線の間隔・谷や尾根の形を見比べ、造成の可能性を調べる場所を探します。" data-en="Compare contour spacing and valley/ridge shapes to identify places for further investigation."></li><li data-ja="造成履歴・測量図・現地情報で確認してください。陥没の点も正確な事故座標とは限りません。" data-en="Verify with earthwork records, survey plans and field evidence. Collapse markers may be representative locations."></li></ol>
 <p><a href="https://ktgis.net/kjmapw/tilemapservice.html" target="_blank" rel="noopener noreferrer">今昔マップ on the web — <span data-ja="タイル提供・対象地域" data-en="Tile service / coverage"></span></a></p>
 <p><a id="history-provider" target="_blank" rel="noopener noreferrer" data-ja="この場所を今昔マップで確認" data-en="Inspect this location on Konjaku Map"></a></p>
 <p data-ja="直接表示：今昔マップ全60地域・323年代セット＋能登拡張5年代＋関東迅速測図。全国すべての場所・年代を網羅するものではありません。" data-en="Direct layers: all 60 Konjaku regions / 323 periods, five additional Noto periods, and Kanto rapid survey maps. Coverage is not nationwide or continuous."></p>
 <p><a href="https://service.gsi.go.jp/map-photos/app/map" target="_blank" rel="noopener noreferrer" data-ja="未収録地域：国土地理院の旧版地図を探す ↗" data-en="Other areas: search GSI historical maps ↗"></a></p>
 <p><a href="https://www.gis-okinawa.jp/00z/ViewerIndex.html" target="_blank" rel="noopener noreferrer" data-ja="沖縄・離島の追加資料（提供元で閲覧）↗" data-en="Additional Okinawa and island maps (external viewer) ↗"></a></p>
 <p><a href="https://ktgis.net/kjmapw/note.html" target="_blank" rel="noopener noreferrer" data-ja="今昔マップの利用条件" data-en="Konjaku Map terms"></a></p>
 </details></section>
 <section class="terrain-legend"><h3 data-ja="地形の凡例・データ情報" data-en="Terrain legend and data"></h3><div id="base-meta"></div><p id="terrain-status" role="status"></p></section>`;
 $('#basemap').innerHTML=Object.entries(baseMaps).map(([k,v])=>'<option value="'+k+'">'+esc(t(v.ja,v.en))+'</option>').join('');
 $('#history-region').innerHTML=historicalCatalog.map(r=>'<option value="'+esc(r.id)+'">'+esc(r.name)+'</option>').join('');$('#history-region').value=terrain.region;
 const stamp=document.createElement('div');stamp.id='history-stamp';stamp.hidden=true;stamp.setAttribute('role','status');$('.workspace-top').after(stamp);
 populateHistoryPeriods();terrain.ready=true;
 $('#basemap').onchange=()=>{terrain.base=$('#basemap').value;clearMapSummary();changeBaseMap();if(historyVisible()&&map.getZoom()<(historyRegion().minZoom??8))jumpHistoryRegion();};
 $('#compare-history').onchange=()=>{terrain.compare=$('#compare-history').checked;changeHistoricalMap();if(historyVisible()&&map.getZoom()<(historyRegion().minZoom??8))jumpHistoryRegion();};
 $('#history-region').onchange=()=>{terrain.region=$('#history-region').value;terrain.period=0;populateHistoryPeriods();changeHistoricalMap();jumpHistoryRegion();};
 $('#history-period').onchange=()=>{terrain.period=Number($('#history-period').value);changeHistoricalMap();};
 $('#history-opacity').oninput=()=>{terrain.opacity=Number($('#history-opacity').value);terrain.historyLayer?.setOpacity(terrain.base==='historical'?1:terrain.opacity/100);updateTerrainUI();};
 $('#history-jump').onclick=jumpHistoryRegion;
 $('#history-nearby').onclick=findHistoryHere;
 $('#history-coverage').onchange=renderHistoricalCoverage;
 map.on('moveend zoomend',()=>{$('#history-matches').replaceChildren();updateTerrainUI();});changeBaseMap();
 const attribution=document.createElement('div');attribution.className='attribution-footer';$('#pane-map').after(attribution);attribution.append(map.attributionControl.getContainer());
}
function populateHistoryPeriods(){
 $('#history-period').innerHTML=historyRegion().periods.map((p,i)=>'<option value="'+i+'">'+p.start+(p.end!==p.start?'–'+p.end:'')+t('年','')+' · '+esc(p.scale)+'</option>').join('');$('#history-period').value=String(terrain.period);
}
function monitorTiles(layer,key){
 layer.on('loading',()=>{terrain.errors.delete(key);updateTerrainUI();});layer.on('tileerror',()=>{terrain.errors.add(key);updateTerrainUI();});layer.on('load',updateTerrainUI);return layer;
}
function changeBaseMap(){
 if(tileLayer){map.removeLayer(tileLayer);tileLayer=null;}terrain.errors.delete('base');
 const base=baseMaps[terrain.base];
 if(base.tile){
  let attr='<a href="https://maps.gsi.go.jp/development/ichiran.html" target="_blank" rel="noopener noreferrer">地理院タイル / GSI</a>';
  if(terrain.base==='pale')attr+=' · Shoreline: NIMA VMAP0 / USGS (1997)';
  if(terrain.base==='relief')attr+=' · 海域部は海上保安庁海洋情報部の資料を使用して作成';
  if(terrain.base==='photo')attr+=' · GSI / 林野庁 / 地方公共団体 · Landsat8 (GSI, TSIC, GEO Grid/AIST; USGS) / GEBCO · NASA/USGS EROS · GRUS © Axelspace';
  tileLayer=monitorTiles(L.tileLayer('https://cyberjapandata.gsi.go.jp/xyz/'+base.tile+'/{z}/{x}/{y}.'+(base.ext||'png'),{minZoom:base.min,maxZoom:18,maxNativeZoom:base.max,attribution:attr,className:'current-base-tiles'}),'base').addTo(map);
 }
 changeHistoricalMap();
}
function changeHistoricalMap(){
 if(terrain.historyLayer){map.removeLayer(terrain.historyLayer);terrain.historyLayer=null;}terrain.errors.delete('history');
 if(historyVisible()){
  const region=historyRegion(),p=historyPeriod();
  const url=region.tile?region.tile.replace('{folder}',p.folder):'https://ktgis.net/kjmapw/kjtilemap/'+region.id+'/'+p.folder+'/{z}/{x}/{y}.png';
  const bounds=historyBounds(region,p);
  terrain.historyLayer=monitorTiles(L.tileLayer(url,{tms:region.tms!==false,pane:'historicalMap',minZoom:region.minZoom??8,maxZoom:18,maxNativeZoom:p.maxZoom,bounds:[[bounds[0],bounds[1]],[bounds[2],bounds[3]]],opacity:terrain.base==='historical'?1:terrain.opacity/100,attribution:historyAttribution(region),keepBuffer:1}),'history').addTo(map);
 }
 renderHistoricalCoverage();updateTerrainUI();
}
function renderHistoricalCoverage(){
 if(terrain.coverage){map.removeLayer(terrain.coverage);terrain.coverage=null;}
 if(!historyVisible()||!$('#history-coverage').checked)return;
 const renderer=terrain.coverageRenderer;
 terrain.coverage=L.featureGroup(historyPeriod().sheets.map(s=>L.rectangle([[s.bounds[0],s.bounds[1]],[s.bounds[2],s.bounds[3]]],{renderer,pane:'historicalCoverage',color:'#1f649a',dashArray:'6 5',weight:1.5,fill:false,interactive:false}))).addTo(map);
}
function updateTerrainUI(){
 if(!terrain.ready)return;
 $('#terrain-summary').textContent=t('背景地図・地形比較','Base maps & terrain comparison');
 $$('[data-ja][data-en]').forEach(el=>el.textContent=lang==='en'?el.dataset.en:el.dataset.ja);
 for(const option of $('#basemap').options){const b=baseMaps[option.value];option.textContent=t(b.ja,b.en);}
 $('#history-options').hidden=!historyVisible();$('#compare-history').disabled=terrain.base==='historical';
 $('#history-opacity').disabled=terrain.base==='historical';$('#history-opacity-value').textContent=(terrain.base==='historical'?100:terrain.opacity)+'%';
 populateHistoryPeriods();
 $('#history-date-caption').textContent=t(historyRegion().dateType==='publication'?'発行年':historyRegion().dateType==='survey'?'測量年':'収録年代',historyRegion().dateType==='publication'?'Publication years':historyRegion().dateType==='survey'?'Survey years':'Map period');
 $('#history-coverage').disabled=!historyPeriod().sheets.length;
 const stamp=$('#history-stamp');stamp.hidden=!historyVisible()||view!=='map';
 if(historyVisible())stamp.textContent=historyRegion().name+' ｜ '+historyDateLabel(historyRegion(),historyPeriod());
 const b=baseMaps[terrain.base],z=map.getZoom(),center=map.getCenter();
 const notes={
 pale:t('国土地理院・淡色地図。地名を読むときは標準地図に切り替えられます。','GSI pale map. Switch to Standard for clearer place labels.'),
 std:t('国土地理院・標準地図。地名と等高線は配信画像の文字・線です。','GSI standard map. Labels and contours are part of the map image.'),
 photo:t('国土地理院・全国最新写真。ズーム14–18は主に航空写真、9–13はLandsat、2–8は全球衛星画像です。撮影年・画素寸法は地域ごとに異なり、この画面では未取得です。','GSI seamless imagery: mainly aerial photos at zoom 14–18, Landsat at 9–13 and global satellite imagery at 2–8. Local acquisition dates and pixel sizes are not retrieved here.'),
 hill:t('陰影は斜面の向きと起伏を表し、標高値の色ではありません。国土地理院DEM由来。ズーム2–12はDEM10B（10m）、13–16はDEM5A・5B（5m）とDEM10B（10m）の混在です。','Shading depicts slope direction and relief, not elevation colors. GSI DEM10B (10 m) at zoom 2–12; DEM5A/5B (5 m) and DEM10B (10 m) at 13–16.'),
 relief:t('国土地理院の色別標高図（段彩＋陰影）。陸域は主に10m DEM、ズーム14・15では5m DEMを併用。海域は500m海底地形です。測量地区の境目や水部には見かけの段差が生じる場合があります。','GSI elevation colors with shading. Mainly 10 m DEM on land, supplemented by 5 m DEM at zoom 14–15; 500 m seabed data offshore. Apparent steps can occur at survey boundaries and water edges.'),
 historical:t('旧版地形図のみを表示しています。未提供部分は灰色・空白です。現在の背景地図を選び「古地図を透過して比較する」を有効にすると比較できます。','Historical map only. Unavailable areas are gray or blank. For comparison, select a current base map and enable the historical overlay.')};
 let text='<p>'+esc(notes[terrain.base])+'</p>';
 if(terrain.base==='relief')text+='<p>'+t('標高：緑（低い）→黄→茶（高い）。公式凡例の目盛は 0・100・300・1,000・2,000・4,000 m。水深：浅い青緑→深い青で、0・500・1,000・2,000・4,000・8,000・12,000 m。色は陰影によって変化します。','Elevation: green (low), yellow, then brown (high). Official ticks: 0, 100, 300, 1,000, 2,000 and 4,000 m. Water depth: light teal (shallow) to blue (deep), at 0, 500, 1,000, 2,000, 4,000, 8,000 and 12,000 m. Shading changes the appearance of these colors.')+'</p><details><summary>'+t('公式の凡例画像を見る','View the official legend image')+'</summary><figure class="elevation-key"><img src="https://cyberjapandata.gsi.go.jp/legend/Relief_hanrei.png" alt="'+t('国土地理院の標高段彩凡例。単位メートル。','Official GSI elevation color legend, in metres.')+'"><figcaption>'+t('地形の標高（m）・国土地理院の公式凡例','Terrain elevation (m): official GSI legend')+'</figcaption></figure></details>';
 if(terrain.base==='relief')text+='<p><a href="https://maps.gsi.go.jp/legend/attension_relief.html" target="_blank" rel="noopener noreferrer">'+t('標高段彩の公式凡例・注意事項（単位m）','Official elevation legend and notes (metres)')+'</a></p>';
 if(terrain.base==='hill'||terrain.base==='relief')text+='<p>'+t('地形の色・陰影と、陥没件数の凡例は別です。測量時期・地点ごとの誤差は未取得。点の標高値や標高差は表示していません。','Terrain colors/shading are separate from collapse counts. Local survey dates and errors are not retrieved. Point elevations and elevation differences are not displayed.')+'</p>';
 if(terrain.base!=='historical')text+='<p>'+t('「現在」は現在配信中の地図を意味し、今日の測量ではありません。地域ごとの作成年・測量年は提供元で確認してください。','“Current” means the map currently served, not surveyed today. Check the provider for local compilation and survey dates.')+'</p>';
 $('#base-meta').innerHTML=text;
 const problems=[];
 if(b.min&&z<b.min)problems.push(t('この背景地図はズーム'+b.min+'以上で表示します。拡大してください。','This base map needs zoom '+b.min+' or greater.'));
 if(historyVisible()&&z<(historyRegion().minZoom??8))problems.push(t('古地図は拡大すると表示されます。「この地域を表示」で移動できます。','Zoom in or use Go to this region to display historical tiles.'));
 if(b.max&&z>b.max)problems.push(t('最大提供ズームの画像を拡大しています。精度は向上しません。','Image enlarged beyond native zoom; accuracy does not improve.'));
 if(terrain.errors.size)problems.push(t('一部のタイルが未提供または取得失敗です。別の地図・標高値で補完していません。','Some tiles are missing or failed to load. No replacement map or elevation is substituted.'));
 $('#terrain-status').textContent=problems.join(' ');
 if(historyVisible()){
  const region=historyRegion(),p=historyPeriod(),sheets=p.sheets.filter(s=>sheetContains(s,center.lat,center.lng));
  $('#history-meta').textContent=t('対象地域：','Region: ')+region.name+' ／ '+historyDateLabel(region,p)+' ／ '+t('原図縮尺 ','Original scale ')+p.scale+' ／ '+t('出典：','Source: ')+(region.provider||'今昔マップ on the web')+t('。地域・年代によって提供範囲は異なります。','; coverage varies by region and period.');
  $('#history-center').textContent=region.coverageApproximate?t('この資料は図幅ごとの境界・図歴を未取得です。地域の目安範囲を使って検索していますが、範囲内にも空白があります。表示画像と提供元で収録範囲を確認してください。','Individual sheet footprints and histories are unavailable. Search uses an approximate regional extent; blank areas may occur inside it. Check the imagery and provider.'):(sheets.length?t('地図中央の図幅：','Sheet at map center: ')+sheets.map(s=>s.name+' — '+(s.note||t('測量・作成年未取得','Survey date unavailable'))).join(' / ')+t('（収録年代と測量・発行年は異なる場合があります。）',' (Period, survey and publication dates may differ.)'):t('地図中央はこの地域・年代の収録図幅外です。「この場所の古地図を探す」で他の資料を確認できます。','The center is outside this period’s sheets. Use Find historical maps here to check other sources.'));
  $('#history-provider').href=region.source||'https://ktgis.net/kjmapw/kjmapw.html?lat='+center.lat+'&lng='+center.lng+'&zoom='+Math.max(8,Math.min(p.maxZoom,Math.round(z)))+'&dataset='+encodeURIComponent(region.id)+'&age='+terrain.period+'&map2type=roadmap&dual=true';
  $('#history-provider').textContent=t('この古地図の提供元・対象範囲を見る','View this map’s source and coverage');
 }
}

function historyBounds(region,p){
 if(region.coverageBounds)return region.coverageBounds;
 return [Math.min(...p.sheets.map(s=>s.bounds[0])),Math.min(...p.sheets.map(s=>s.bounds[1])),Math.max(...p.sheets.map(s=>s.bounds[2])),Math.max(...p.sheets.map(s=>s.bounds[3]))];
}
function historyDateLabel(region,p){return t(region.dateType==='publication'?'発行年 ':region.dateType==='survey'?'測量年 ':'収録年代 ',region.dateType==='publication'?'Published ':region.dateType==='survey'?'Surveyed ':'Map period ')+p.start+(p.end!==p.start?'–'+p.end:'')+t('年','');}
function historyAttribution(region){
 if(region.id==='naro-rapid')return '<a href="https://habs.rad.naro.go.jp/" target="_blank" rel="noopener noreferrer">農研機構農業環境研究部門</a> / <a href="https://creativecommons.org/licenses/by/2.1/jp/" target="_blank" rel="noopener noreferrer">CC BY 2.1 JP</a>';
 return '<a href="'+(region.source||'https://ktgis.net/kjmapw/')+'" target="_blank" rel="noopener noreferrer">'+esc(region.provider||'今昔マップ on the web')+'</a>'+(region.provider?'':' © 谷謙二');
}
function jumpHistoryRegion(){const b=historyBounds(historyRegion(),historyPeriod());map.fitBounds([[b[0],b[1]],[b[2],b[3]]],{maxZoom:12,padding:[16,16],animate:false});}
function historicalMatches(lat,lng){return historicalCatalog.flatMap(region=>{const periods=region.periods.map((p,index)=>({p,index})).filter(({p})=>region.coverageBounds?sheetContains({bounds:region.coverageBounds},lat,lng):p.sheets.some(s=>sheetContains(s,lat,lng)));return periods.length?[{region,periods}]:[];});}
function findHistoryHere(){
 const center=map.getCenter(),matches=historicalMatches(center.lat,center.lng),target=$('#history-matches');
 target.replaceChildren();
 const note=document.createElement('p');note.textContent=matches.length?t('地図中央に対応する資料（年代を選択）','Sources at the map center (choose a period)'):t('この場所で直接表示できる古地図は見つかりませんでした。下の外部資料もご確認ください。','No integrated historical map was found here. Check the external sources below.');target.append(note);
 matches.forEach(({region,periods})=>{const details=document.createElement('details'),summary=document.createElement('summary');summary.textContent=region.name+(region.coverageApproximate?t('（概略範囲）',' (approximate extent)'):'');details.append(summary);periods.forEach(({p,index})=>{const button=document.createElement('button');button.textContent=historyDateLabel(region,p);button.onclick=()=>{terrain.region=region.id;terrain.period=index;$('#history-region').value=region.id;populateHistoryPeriods();changeHistoricalMap();};details.append(button);});target.append(details);});
}

'use strict';
const gridSteps=km=>[km/111.32,km/(111.32*Math.cos(36*Math.PI/180))];
function gridIndex(r,km){const [dy,dx]=gridSteps(km);return Math.floor(r.lat/dy)+':'+Math.floor(r.lon/dx);}
function aggregateGrid(records,km){const cells=new Map();for(const r of records){if(!mapped(r))continue;const key=gridIndex(r,km);if(!cells.has(key))cells.set(key,[]);cells.get(key).push(r);}return cells;}
function gridBounds(key,km){const [iy,ix]=key.split(':').map(Number),[dy,dx]=gridSteps(km);return [[iy*dy,ix*dx],[(iy+1)*dy,(ix+1)*dx]];}
function featureName(f){let p=f.properties||{};return p.name_ja||p.nam_ja||p.N03_001||p.prefecture||p.name||p.NAME_JA||'';}
let focusedPref=null,prefFocusRenderer,recordRenderer,selectionRenderer;
function prefectureMaskRings(feature){
 const geometry=feature?.geometry;
 const polygons=geometry?.type==='Polygon'?[geometry.coordinates]:geometry?.type==='MultiPolygon'?geometry.coordinates:[];
 const world=[[-85,-180],[-85,180],[85,180],[85,-180]];
 return [world,...polygons.flatMap(polygon=>polygon.map(ring=>ring.map(([lon,lat])=>[lat,lon])))];
}
function syncPrefectureFocus(){
 if(!map)return;
 const name=$('#pref').value;
 if(focusedPref===name)return;
 if(prefLayer){map.removeLayer(prefLayer);prefLayer=null;}
 focusedPref=name;
 const feature=prefFeatures?.features.find(f=>featureName(f)===name);
 if(!name||!feature)return;
 const mask=L.polygon(prefectureMaskRings(feature),{pane:'prefectureFocus',renderer:prefFocusRenderer,stroke:false,fillColor:'#747b82',fillOpacity:.43,fillRule:'evenodd',interactive:false,className:'prefecture-outside-mask'});
 const border=L.geoJSON(feature,{pane:'prefectureFocus',renderer:prefFocusRenderer,style:{color:'#b85420',weight:2.2,opacity:.95,fill:false,fillOpacity:0},interactive:false,className:'selected-prefecture-boundary'});
 prefLayer=L.featureGroup([mask,border]).addTo(map);
}
function fitJapan(){map?.fitBounds([[24.1,123],[45.7,146.1]],{padding:[25,25],animate:false});}
function initMap(){
 if(!window.L){$('#map-error').hidden=false;$('#map-error').textContent=t('地図を読み込めません。データ一覧をご利用ください。','Map unavailable. Please use the record list.');return;}
 map=L.map('map',{zoomControl:false,minZoom:3,maxZoom:18,zoomSnap:.5,preferCanvas:true,attributionControl:true});
 map.createPane('recordOverlay').style.zIndex='460';map.createPane('selectedRecord').style.zIndex='650';recordRenderer=L.canvas({pane:'recordOverlay'});selectionRenderer=L.svg({pane:'selectedRecord'});
 const focusPane=map.createPane('prefectureFocus');focusPane.style.zIndex='450';focusPane.style.pointerEvents='none';prefFocusRenderer=L.svg({pane:'prefectureFocus'});
 L.DomEvent.disableClickPropagation($('#legend'));L.DomEvent.disableScrollPropagation($('#legend'));
 L.control.zoom({position:'topright'}).addTo(map);L.control.scale({imperial:false,position:'bottomright'}).addTo(map);fitJapan();
 if(prefFeatures)outline=L.geoJSON(prefFeatures,{style:{color:'#8d8078',weight:.5,fill:false,fillOpacity:0,opacity:.35},interactive:false}).addTo(map);
 map.on('moveend',()=>{if(!navigationMoving&&$('#in-bounds').checked)applyFilters();});
 map.attributionControl.addAttribution('<a href="https://github.com/dataofjapan/land" target="_blank" rel="noopener">Boundary: dataofjapan / GSI</a> · <a href="https://www.mlit.go.jp/road/sisaku/ijikanri/dourokanbotsu.html" target="_blank" rel="noopener">Data: MLIT (edited)</a>');
}
function clusterIcon(count){const size=count>=1000?64:count>=100?56:count>=10?48:40;return L.divIcon({className:'cluster-icon '+(count>=100?'large':''),html:'<span>'+fmt(count)+'</span>',iconSize:[size,size],iconAnchor:[size/2,size/2]});}
const gridPalette=[[255,242,196],[249,150,53],[158,47,7]];
function gridColorAt(fraction){
 const x=Math.max(0,Math.min(1,fraction))*(gridPalette.length-1),i=Math.min(gridPalette.length-2,Math.floor(x)),blend=x-i;
 return 'rgb('+gridPalette[i].map((v,c)=>Math.round(v+(gridPalette[i+1][c]-v)*blend)).join(',')+')';
}
let manualGridLimits=null,gridScaleSignature='',currentGridCells=null,currentScaleCells=null,densityCells=[],currentGridKm=10;
function normalizeGridLimits(max,limits){
 if(max<=0)return {lower:0,upper:1};
 const upper=Math.max(1,Math.min(max,Math.round(limits?.upper??max)));
 const lower=Math.max(0,Math.min(upper-1,Math.round(limits?.lower??0)));
 return {lower,upper};
}
function buildGridScale(cells,limits=null){
 const counts=[...cells.values()].map(rs=>rs.length).filter(n=>n>0).sort((a,b)=>a-b),max=counts.at(-1)||0;
 // Each occupied cell has equal weight; a few dense cells must not flatten the rest.
 const percentile=counts[Math.ceil(counts.length*.95)-1]||1,unit=10**Math.floor(Math.log10(percentile));
 const autoUpper=Math.min(max||1,[1,2,4,6,8,10].find(step=>step*unit>=percentile)*unit);
 const {lower,upper}=normalizeGridLimits(max,limits||{lower:0,upper:autoUpper});
 return {max,lower,upper,color:n=>max>0&&n>0?gridColorAt((n-lower)/(upper-lower)):'transparent',gradient:'linear-gradient(90deg in srgb, '+gridPalette.map(rgb=>'rgb('+rgb.join(',')+')').join(', ')+')'};
}
function prepareGridScale(cells,km){
 const playbackCells=typeof playbackScaleCells==='function'?playbackScaleCells(km):null;
 const signature=playbackCells?'playback|'+playback.signature+'|'+playback.mode+'|'+km:scope+'|'+km+'|'+[...cells].map(([key,rs])=>key+':'+rs.length).sort().join('|');
 if(signature!==gridScaleSignature){manualGridLimits=null;gridScaleSignature=signature;}
 currentGridCells=cells;currentScaleCells=playbackCells||cells;currentGridKm=km;
 return buildGridScale(currentScaleCells,manualGridLimits);
}
function gridLegend(scale,km){
 return '<strong>'+t('メッシュ内の記録数','Records per grid cell')+'</strong><small>'+t('約'+km+' km四方・緯度36°基準','Approx. '+km+' km square at 36°N')+'</small>'
 +(scale.max?'<div class="gradient-scale" role="img" id="gradient-scale"><div class="gradient-strip" style="background:'+scale.gradient+'"></div><div class="gradient-labels"><span id="scale-low">'+fmt(scale.lower)+'</span><span id="scale-high">'+fmt(scale.upper)+t('件',' records')+'</span></div></div>'
 +'<div class="legend-ranges"><label for="color-min">'+t('色の下限','Color minimum')+'</label><input type="range" id="color-min" min="0" max="'+Math.max(0,scale.max-1)+'" step="1" value="'+scale.lower+'"><output id="color-min-value">'+fmt(scale.lower)+'</output>'
 +'<label for="color-max">'+t('色の上限','Color maximum')+'</label><input type="range" id="color-max" min="1" max="'+scale.max+'" step="1" value="'+scale.upper+'"><output id="color-max-value">'+fmt(scale.upper)+'</output></div>'
 +'<div class="legend-scale-status"><small>'+(typeof playback!=='undefined'&&playback.active?t('再生期間内の最大：','Playback maximum: '):t('実際の最大：','Observed maximum: '))+fmt(scale.max)+t('件',' records')+'</small><button id="color-auto">'+t('自動に戻す','Auto scale')+'</button></div>'
 +'<small class="scale-note">'+t('自動の上限は、記録のあるメッシュの95％を含む件数を目安に調整します。上限以上は最濃色で表示し、記録は除外しません。条件・メッシュ幅の変更で再計算します。時系列再生中は期間共通の基準です。','Auto uses a rounded 95th percentile of occupied cell counts. Counts at or above the limit use the darkest shade; no records are excluded. Filters and cell size recalculate the scale. Playback uses a shared scale across its periods.')+'</small>'
 :'<small>'+t('地図に表示できる記録がありません','No located records')+'</small>');
}
function updateGridLegendUI(scale){
 $('#color-min').value=scale.lower;$('#color-max').value=scale.upper;
 $('#color-min').disabled=scale.max<=1;$('#color-max').disabled=scale.max<=1;
 $('#color-min-value').textContent=fmt(scale.lower);$('#color-max-value').textContent=fmt(scale.upper);
 $('#scale-low').textContent=fmt(scale.lower);$('#scale-high').textContent=fmt(scale.upper)+(scale.upper<scale.max?t('件以上','+ records'):t('件',' records'));
 $('#gradient-scale').setAttribute('aria-label',t(scale.lower+'件から'+scale.upper+'件までの連続色分け','Continuous color scale from '+scale.lower+' to '+scale.upper+' records'));
 $('#color-min').setAttribute('aria-valuetext',fmt(scale.lower)+t('件',' records'));$('#color-max').setAttribute('aria-valuetext',fmt(scale.upper)+t('件',' records'));
 $('#color-auto').disabled=manualGridLimits===null;
}
function recolorGrid(){
 const scale=buildGridScale(currentScaleCells||currentGridCells,manualGridLimits);
 for(const {layer,count} of densityCells)layer.setStyle({color:scale.color(count),fillColor:scale.color(count)});
 updateGridLegendUI(scale);
 if(typeof updateMobileUI==='function')updateMobileUI();
}
function changeGridColorBound(side,value){
 if(!currentGridCells)return;
 const scale=buildGridScale(currentScaleCells||currentGridCells,manualGridLimits),v=Math.round(Number(value));
 if(!Number.isFinite(v)||scale.max<1)return;
 manualGridLimits={lower:scale.lower,upper:scale.upper};
 if(side==='min')manualGridLimits.lower=Math.max(0,Math.min(v,scale.upper-1));
 else manualGridLimits.upper=Math.max(scale.lower+1,Math.min(v,scale.max));
 recolorGrid();
}
function wireGridLegend(scale){
 if(!scale.max)return;
 $('#color-min').oninput=()=>changeGridColorBound('min',$('#color-min').value);
 $('#color-max').oninput=()=>changeGridColorBound('max',$('#color-max').value);
 $('#color-auto').onclick=()=>{manualGridLimits=null;recolorGrid();};
 updateGridLegendUI(scale);
 if(typeof updateMobileUI==='function')updateMobileUI();
}
function depthRange(rs){const values=rs.map(r=>r.depthM).filter(num);return values.length?fmt(Math.min(...values))+'–'+fmt(Math.max(...values))+' m':t('未記載','Not reported');}
function recordTooltip(r){return `<div class="record-tooltip"><strong>${esc(recordTitle(r))}</strong><span>${esc(prefLabel(r.prefecture))} · ${esc(dateLabel(r))}</span><span>${esc(r.address)}</span><b>${t('深さ','Depth')} ${num(r.depthM)?fmt(r.depthM)+' m':t('未記載','not reported')}</b><span>${t('縦 × 横','Length × width')}: ${dim(r.lengthM)} × ${dim(r.widthM)} m</span><span>${esc(causeLabel(caseField(r,'cause')||r.cause))}</span><small>${esc(shortPrecision(r))} · ${t('クリックで詳細','Click for details')}</small></div>`;}
function groupTooltip(rs,heading){const coarse=rs.filter(r=>precisionCode(r)==='city').length;return `<div class="record-tooltip"><strong>${esc(heading)} · ${fmt(rs.length)} ${t('件','records')}</strong><span>${t('深さ','Depth')}: ${depthRange(rs)}</span><span>${t('市区町村までの住所','Municipality-only locations')}: ${fmt(coarse)}</span>${rs.slice(0,3).map(r=>`<span>• ${esc(recordTitle(r))} / ${num(r.depthM)?fmt(r.depthM)+' m':'—'}</span>`).join('')}<small>${t('代表位置の集計です。クリックして記録を確認。','Aggregated representative locations. Click to inspect records.')}</small></div>`;}
function pointPopup(k,rs){return `${groupTooltip(rs,t('同じ代表位置','Shared representative location'))}<div class="popup-records">${rs.slice(0,8).map(r=>`<button class="popup-record" data-record="${esc(r.id)}">${esc(recordTitle(r))}<small>${esc(dateLabel(r))} · ${t('深さ','Depth')} ${dim(r.depthM)} m</small></button>`).join('')}</div><button data-point="${esc(k)}">${t('この位置の全記録を表示','List all records at this position')} (${fmt(rs.length)}) →</button>`;}
function updateMapNotice(){
 const coarse=filtered.filter(r=>precisionCode(r)==='city').length;
 $('#map-notice').innerHTML=`<span>ⓘ</span><span>${mode==='density'?t('色はメッシュ内の記録数。','Color shows records per grid cell.'):t('点をタップ／クリックして記録を選択。','Tap or click a point to select a record.')} ${t('点は住所の代表位置です。','Points are representative locations.')} ${coarse?t(`市区町村までの ${fmt(coarse)} 件は同じ位置に重なるため、細かな分布は「町丁目まで分かる」で確認してください。`,`${fmt(coarse)} municipality-only records may overlap. Choose “Neighborhood identified” for finer patterns.`):''}</span>`;
}
function clearMapData(){densityCells=[];if(clusters){map.removeLayer(clusters);clusters.clearLayers();clusters=null;}if(densityLayer){map.removeLayer(densityLayer);densityLayer=null;}if(selectedLayer){map.removeLayer(selectedLayer);selectedLayer=null;}}
function updateRecordOpacity(){
 if(!map)return;
 const value=Math.max(0,Math.min(1,Number($('#overlay-opacity').value)/100));
 $('#opacity-value').textContent=Math.round(value*100)+'%';
 map.getPane('recordOverlay').style.opacity=String(value);
 map.getPane('recordOverlay').style.pointerEvents=value===0?'none':'';
}
function renderMap(){
 if(!map)return;syncPrefectureFocus();clearMapData();clearMapSummary();
 $('#mode-density').classList.toggle('active',mode==='density');$('#mode-cluster').classList.toggle('active',mode==='cluster');$('#density-options').hidden=mode!=='density';updateMapNotice();
 if(mode==='density'){
  const km=Number($('#grid-size').value)||10,cells=aggregateGrid(filtered,km),scale=prepareGridScale(cells,km);densityLayer=L.featureGroup().addTo(map);
  const renderer=recordRenderer;
  for(const [key,rs] of cells){
   const rect=L.rectangle(gridBounds(key,km),{pane:'recordOverlay',renderer,color:scale.color(rs.length),weight:.5,opacity:1,fillColor:scale.color(rs.length),fillOpacity:1});
   bindMapSummary(rect,groupTooltip(rs,t('約'+km+' kmメッシュ','Approx. '+km+' km cell')));
   rect.on('click',()=>openCandidates(rs,t('メッシュ内の記録','Records in this cell')));
   densityLayer.addLayer(rect);densityCells.push({layer:rect,count:rs.length});
  }
  $('#legend').innerHTML=gridLegend(scale,km);wireGridLegend(scale);
 }else{
  $('#legend').innerHTML='<strong>'+t('陥没記録の凡例：原因・要因施設','Collapse legend: cause / facility')+'</strong>'+Object.entries(colors).map(([label,color])=>'<span><i style="background:'+color+'"></i>'+esc(causeLabel(label))+'</span>').join('');
  const groups=new Map();filtered.filter(mapped).forEach(r=>{const k=keyPoint(r);if(!groups.has(k))groups.set(k,[]);groups.get(k).push(r);});
  clusters=L.markerClusterGroup({clusterPane:'recordOverlay',showCoverageOnHover:false,maxClusterRadius:45,animate:false,spiderfyOnMaxZoom:false,zoomToBoundsOnClick:false,iconCreateFunction:c=>clusterIcon(c.getAllChildMarkers().reduce((s,m)=>s+m.options.records.length,0))});
  const markers=[];
  for(const [k,rs] of groups){
   const r=rs[0],marker=L.marker([r.lat,r.lon],{pane:'recordOverlay',records:rs,keyboard:true,title:recordTitle(r),icon:rs.length>1?clusterIcon(rs.length):L.divIcon({className:'event-dot',html:'<span style="background:'+colors[causeGroup(r)]+'"></span>',iconSize:[44,44],iconAnchor:[22,22]})});
   bindMapSummary(marker,rs.length===1?recordTooltip(r):groupTooltip(rs,t('同じ代表位置','Shared location')));
   marker.on('click',()=>{if(!tapAllowed())return;clearMapSummary();if(rs.length===1)openDetail(r.id,false);else openCandidates(rs,t('同じ代表位置','Shared location'));});
   markers.push(marker);
  }
  clusters.on('clusterclick',e=>openCandidates(e.layer.getAllChildMarkers().flatMap(m=>m.options.records),t('この範囲の記録','Records in this area')));
  clusters.on('clustermouseover',e=>{if(matchMedia('(hover:hover) and (pointer:fine)').matches&&!touchGesture&&!e.originalEvent?.sourceCapabilities?.firesTouchEvents){$('#map-summary').innerHTML=groupTooltip(e.layer.getAllChildMarkers().flatMap(m=>m.options.records),t('この範囲の記録','Records in this area'));$('#map-summary').hidden=false;}});
  clusters.on('clustermouseout',clearMapSummary);clusters.addLayers(markers);map.addLayer(clusters);
 }
 updateRecordOpacity();showSelectedPoint();
 if(typeof updateMobileUI==='function')updateMobileUI();
}
function showSelectedPoint(){
 if(!map)return;if(selectedLayer){map.removeLayer(selectedLayer);selectedLayer=null;}
 const r=ids.get(selected);if(!r||!mapped(r)||(typeof playback!=='undefined'&&playback.active&&!filtered.some(item=>item.id===r.id)))return;
 selectedLayer=L.circleMarker([r.lat,r.lon],{pane:'selectedRecord',renderer:selectionRenderer,radius:18,color:'#542200',weight:5,fillColor:'#fff',fillOpacity:.65,interactive:false,className:'selected-record-ring'}).addTo(map);
}

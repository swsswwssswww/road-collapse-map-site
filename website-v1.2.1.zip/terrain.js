'use strict';
const terrain={base:'pale',compare:false,region:'tokyo50',period:0,opacity:50,historyLayer:null,coverage:null,ready:false,errors:new Set()};
const baseMaps={
 pale:{ja:'淡色地図',en:'Pale map',tile:'pale',min:2,max:18},
 std:{ja:'標準地図（地名を読みやすく）',en:'Standard map (clear labels)',tile:'std',min:2,max:18},
 photo:{ja:'航空写真（広域は衛星画像）',en:'Aerial / satellite imagery',tile:'seamlessphoto',ext:'jpg',min:2,max:18},
 hill:{ja:'陰影起伏図（DEM）',en:'Hillshade (DEM)',tile:'hillshademap',min:2,max:16},
 relief:{ja:'標高段彩図（DEM・陰影付き）',en:'Elevation colors with shading (DEM)',tile:'relief',min:5,max:15},
 historical:{ja:'古地図・旧版地形図',en:'Historical topographic map'}
};
function historyRegion(){return historicalCatalog.find(r=>r.id===terrain.region)||historicalCatalog[0];}
function historyPeriod(){return historyRegion().periods[terrain.period]||historyRegion().periods[0];}
function historyVisible(){return terrain.base==='historical'||terrain.compare;}
function sheetContains(sheet,lat,lon){const [s,w,n,e]=sheet.bounds;return lat>=s&&lat<=n&&lon>=w&&lon<=e;}
function initTerrain(){
 if(!map)return;
 map.createPane('historicalMap').style.zIndex='250';
 map.createPane('historicalCoverage').style.zIndex='410';map.getPane('historicalCoverage').style.pointerEvents='none';terrain.coverageRenderer=L.canvas({pane:'historicalCoverage'});
 $('#terrain-body').innerHTML=`
 <label><span data-ja="背景地図" data-en="Base map"></span><select id="basemap"></select></label>
 <label class="checkbox"><input type="checkbox" id="compare-history"><span data-ja="古地図を透過して比較する" data-en="Overlay a historical map"></span></label>
 <section id="history-options" hidden>
 <div class="terrain-fields"><label><span data-ja="古地図の地域" data-en="Historical map region"></span><select id="history-region"></select></label><label><span data-ja="収録年代" data-en="Map period"></span><select id="history-period"></select></label></div>
 <button id="history-jump" data-ja="この地域を表示" data-en="Go to this region"></button>
 <label><span data-ja="古地図の不透明度（0%＝現在、100%＝古地図）" data-en="Historical opacity (0% current, 100% historical)"></span><input type="range" id="history-opacity" min="0" max="100" step="5" value="50"><output id="history-opacity-value">50%</output></label>
 <label class="checkbox"><input id="history-coverage" type="checkbox" checked><span data-ja="収録図幅を青い破線で表示" data-en="Show map sheets as blue dashed outlines"></span></label>
 <p id="history-meta"></p><p id="history-center" role="status"></p>
 <p class="comparison-warning" data-ja="比較閲覧専用：等高線の違いだけで切土・盛土とは断定できません。位置合わせ・標高基準・解像度・測量時期・誤差を検証していないため、標高差の算出と切土・盛土の自動判定は未対応です。" data-en="Visual comparison only. Contour differences do not establish cut or fill. Registration, vertical datum, resolution, survey dates and errors have not been validated. Elevation differences and automatic cut/fill classification are not supported."></p>
 <details><summary data-ja="比較の見方・資料を確認" data-en="How to compare and check sources"></summary>
 <ol><li data-ja="道路・河川などの変わりにくい目印で位置のずれを確認します。" data-en="Check alignment against stable roads, rivers and other landmarks."></li><li data-ja="等高線の間隔・谷や尾根の形を見比べ、造成の可能性を調べる場所を探します。" data-en="Compare contour spacing and valley/ridge shapes to identify places for further investigation."></li><li data-ja="造成履歴・測量図・現地情報で確認してください。陥没の点も正確な事故座標とは限りません。" data-en="Verify with earthwork records, survey plans and field evidence. Collapse markers may be representative locations."></li></ol>
 <p><a href="https://ktgis.net/kjmapw/tilemapservice.html" target="_blank" rel="noopener noreferrer">今昔マップ on the web — <span data-ja="タイル提供・対象地域" data-en="Tile service / coverage"></span></a></p>
 <p><a id="history-provider" target="_blank" rel="noopener noreferrer" data-ja="この場所を今昔マップで確認" data-en="Inspect this location on Konjaku Map"></a></p>
 <p><a href="https://ktgis.net/kjmapw/note.html" target="_blank" rel="noopener noreferrer" data-ja="今昔マップの利用条件" data-en="Konjaku Map terms"></a></p>
 </details></section>
 <section class="terrain-legend"><h3 data-ja="地形の凡例・データ情報" data-en="Terrain legend and data"></h3><div id="base-meta"></div><p id="terrain-status" role="status"></p></section>`;
 $('#basemap').innerHTML=Object.entries(baseMaps).map(([k,v])=>'<option value="'+k+'">'+esc(t(v.ja,v.en))+'</option>').join('');
 $('#history-region').innerHTML=historicalCatalog.map(r=>'<option value="'+esc(r.id)+'">'+esc(r.name)+'</option>').join('');$('#history-region').value=terrain.region;
 populateHistoryPeriods();terrain.ready=true;
 $('#basemap').onchange=()=>{terrain.base=$('#basemap').value;clearMapSummary();changeBaseMap();};
 $('#compare-history').onchange=()=>{terrain.compare=$('#compare-history').checked;changeHistoricalMap();};
 $('#history-region').onchange=()=>{terrain.region=$('#history-region').value;terrain.period=0;populateHistoryPeriods();changeHistoricalMap();};
 $('#history-period').onchange=()=>{terrain.period=Number($('#history-period').value);changeHistoricalMap();};
 $('#history-opacity').oninput=()=>{terrain.opacity=Number($('#history-opacity').value);terrain.historyLayer?.setOpacity(terrain.base==='historical'?1:terrain.opacity/100);updateTerrainUI();};
 $('#history-jump').onclick=()=>{const bounds=L.latLngBounds(historyPeriod().sheets.flatMap(s=>[[s.bounds[0],s.bounds[1]],[s.bounds[2],s.bounds[3]]]));map.fitBounds(bounds,{maxZoom:12,padding:[16,16],animate:false});};
 $('#history-coverage').onchange=renderHistoricalCoverage;
 map.on('moveend zoomend',updateTerrainUI);changeBaseMap();
 const attribution=document.createElement('div');attribution.className='attribution-footer';$('#pane-map').after(attribution);attribution.append(map.attributionControl.getContainer());
}
function populateHistoryPeriods(){
 $('#history-period').innerHTML=historyRegion().periods.map((p,i)=>'<option value="'+i+'">'+p.start+(p.end!==p.start?'–'+p.end:'')+' · '+esc(p.scale)+'</option>').join('');$('#history-period').value=String(terrain.period);
}
function monitorTiles(layer,key){
 layer.on('loading',()=>{terrain.errors.delete(key);updateTerrainUI();});layer.on('tileerror',()=>{terrain.errors.add(key);updateTerrainUI();});layer.on('load',updateTerrainUI);return layer;
}
function changeBaseMap(){
 if(tileLayer){map.removeLayer(tileLayer);tileLayer=null;}terrain.errors.delete('base');
 const base=baseMaps[terrain.base];
 if(base.tile){
  let attr='<a href="https://maps.gsi.go.jp/development/ichiran.html" target="_blank" rel="noopener noreferrer">地理院タイル / GSI</a>';
  if(terrain.base==='pale')attr+=' · Shoreline: NIMA VMAP0 / USGS (1997)';
  if(terrain.base==='relief')attr+=' · 海域部は海上保安庁海洋情報部の資料を使用して作成';
  if(terrain.base==='photo')attr+=' · GSI / 林野庁 / 地方公共団体 · Landsat8 (GSI, TSIC, GEO Grid/AIST; USGS) / GEBCO · NASA/USGS EROS · GRUS © Axelspace';
  tileLayer=monitorTiles(L.tileLayer('https://cyberjapandata.gsi.go.jp/xyz/'+base.tile+'/{z}/{x}/{y}.'+(base.ext||'png'),{minZoom:base.min,maxZoom:18,maxNativeZoom:base.max,attribution:attr,className:'current-base-tiles'}),'base').addTo(map);
 }
 changeHistoricalMap();
}
function changeHistoricalMap(){
 if(terrain.historyLayer){map.removeLayer(terrain.historyLayer);terrain.historyLayer=null;}terrain.errors.delete('history');
 if(historyVisible()){
  const region=historyRegion(),p=historyPeriod();
  terrain.historyLayer=monitorTiles(L.tileLayer('https://ktgis.net/kjmapw/kjtilemap/'+region.id+'/'+p.folder+'/{z}/{x}/{y}.png',{tms:true,pane:'historicalMap',minZoom:8,maxZoom:18,maxNativeZoom:p.maxZoom,opacity:terrain.base==='historical'?1:terrain.opacity/100,attribution:'<a href="https://ktgis.net/kjmapw/" target="_blank" rel="noopener noreferrer">今昔マップ on the web</a> © 谷謙二',keepBuffer:1}),'history').addTo(map);
 }
 renderHistoricalCoverage();updateTerrainUI();
}
function renderHistoricalCoverage(){
 if(terrain.coverage){map.removeLayer(terrain.coverage);terrain.coverage=null;}
 if(!historyVisible()||!$('#history-coverage').checked)return;
 const renderer=terrain.coverageRenderer;
 terrain.coverage=L.featureGroup(historyPeriod().sheets.map(s=>L.rectangle([[s.bounds[0],s.bounds[1]],[s.bounds[2],s.bounds[3]]],{renderer,pane:'historicalCoverage',color:'#1f649a',dashArray:'6 5',weight:1.5,fill:false,interactive:false}))).addTo(map);
}
function updateTerrainUI(){
 if(!terrain.ready)return;
 $('#terrain-summary').textContent=t('背景地図・地形比較','Base maps & terrain comparison');
 $$('[data-ja][data-en]').forEach(el=>el.textContent=lang==='en'?el.dataset.en:el.dataset.ja);
 for(const option of $('#basemap').options){const b=baseMaps[option.value];option.textContent=t(b.ja,b.en);}
 $('#history-options').hidden=!historyVisible();$('#compare-history').disabled=terrain.base==='historical';
 $('#history-opacity').disabled=terrain.base==='historical';$('#history-opacity-value').textContent=(terrain.base==='historical'?100:terrain.opacity)+'%';
 const b=baseMaps[terrain.base],z=map.getZoom(),center=map.getCenter();
 const notes={
 pale:t('国土地理院・淡色地図。地名を読むときは標準地図に切り替えられます。','GSI pale map. Switch to Standard for clearer place labels.'),
 std:t('国土地理院・標準地図。地名と等高線は配信画像の文字・線です。','GSI standard map. Labels and contours are part of the map image.'),
 photo:t('国土地理院・全国最新写真。ズーム14–18は主に航空写真、9–13はLandsat、2–8は全球衛星画像です。撮影年・画素寸法は地域ごとに異なり、この画面では未取得です。','GSI seamless imagery: mainly aerial photos at zoom 14–18, Landsat at 9–13 and global satellite imagery at 2–8. Local acquisition dates and pixel sizes are not retrieved here.'),
 hill:t('陰影は斜面の向きと起伏を表し、標高値の色ではありません。国土地理院DEM由来。ズーム2–12はDEM10B（10m）、13–16はDEM5A・5B（5m）とDEM10B（10m）の混在です。','Shading depicts slope direction and relief, not elevation colors. GSI DEM10B (10 m) at zoom 2–12; DEM5A/5B (5 m) and DEM10B (10 m) at 13–16.'),
 relief:t('国土地理院の色別標高図（段彩＋陰影）。陸域は主に10m DEM、ズーム14・15では5m DEMを併用。海域は500m海底地形です。測量地区の境目や水部には見かけの段差が生じる場合があります。','GSI elevation colors with shading. Mainly 10 m DEM on land, supplemented by 5 m DEM at zoom 14–15; 500 m seabed data offshore. Apparent steps can occur at survey boundaries and water edges.'),
 historical:t('旧版地形図のみを表示しています。未提供部分は灰色・空白です。現在の背景地図を選び「古地図を透過して比較する」を有効にすると比較できます。','Historical map only. Unavailable areas are gray or blank. For comparison, select a current base map and enable the historical overlay.')};
 let text='<p>'+esc(notes[terrain.base])+'</p>';
 if(terrain.base==='relief')text+='<p>'+t('標高：緑（低い）→黄→茶（高い）。公式凡例の目盛は 0・100・300・1,000・2,000・4,000 m。水深：浅い青緑→深い青で、0・500・1,000・2,000・4,000・8,000・12,000 m。色は陰影によって変化します。','Elevation: green (low), yellow, then brown (high). Official ticks: 0, 100, 300, 1,000, 2,000 and 4,000 m. Water depth: light teal (shallow) to blue (deep), at 0, 500, 1,000, 2,000, 4,000, 8,000 and 12,000 m. Shading changes the appearance of these colors.')+'</p><details><summary>'+t('公式の凡例画像を見る','View the official legend image')+'</summary><figure class="elevation-key"><img src="https://cyberjapandata.gsi.go.jp/legend/Relief_hanrei.png" alt="'+t('国土地理院の標高段彩凡例。単位メートル。','Official GSI elevation color legend, in metres.')+'"><figcaption>'+t('地形の標高（m）・国土地理院の公式凡例','Terrain elevation (m): official GSI legend')+'</figcaption></figure></details>';
 if(terrain.base==='relief')text+='<p><a href="https://maps.gsi.go.jp/legend/attension_relief.html" target="_blank" rel="noopener noreferrer">'+t('標高段彩の公式凡例・注意事項（単位m）','Official elevation legend and notes (metres)')+'</a></p>';
 if(terrain.base==='hill'||terrain.base==='relief')text+='<p>'+t('地形の色・陰影と、陥没件数の凡例は別です。測量時期・地点ごとの誤差は未取得。点の標高値や標高差は表示していません。','Terrain colors/shading are separate from collapse counts. Local survey dates and errors are not retrieved. Point elevations and elevation differences are not displayed.')+'</p>';
 if(terrain.base!=='historical')text+='<p>'+t('「現在」は現在配信中の地図を意味し、今日の測量ではありません。地域ごとの作成年・測量年は提供元で確認してください。','“Current” means the map currently served, not surveyed today. Check the provider for local compilation and survey dates.')+'</p>';
 $('#base-meta').innerHTML=text;
 const problems=[];
 if(b.min&&z<b.min)problems.push(t('この背景地図はズーム'+b.min+'以上で表示します。拡大してください。','This base map needs zoom '+b.min+' or greater.'));
 if(historyVisible()&&z<8)problems.push(t('古地図はズーム8以上で表示します。「この地域を表示」で移動できます。','Historical tiles require zoom 8+. Use Go to this region.'));
 if(b.max&&z>b.max)problems.push(t('最大提供ズームの画像を拡大しています。精度は向上しません。','Image enlarged beyond native zoom; accuracy does not improve.'));
 if(terrain.errors.size)problems.push(t('一部のタイルが未提供または取得失敗です。別の地図・標高値で補完していません。','Some tiles are missing or failed to load. No replacement map or elevation is substituted.'));
 $('#terrain-status').textContent=problems.join(' ');
 if(historyVisible()){
  const region=historyRegion(),p=historyPeriod(),sheets=p.sheets.filter(s=>sheetContains(s,center.lat,center.lng));
  $('#history-meta').textContent=t('対象地域：','Region: ')+region.name+' ／ '+p.start+(p.start!==p.end?'–'+p.end:'')+' ／ '+t('原図縮尺 ','Original scale ')+p.scale+' ／ '+t('出典：今昔マップ on the web（原図：国土地理院等）。青い破線は収録図幅で、地域全域を覆うものではありません。空白・図幅外・欠測部分では比較できません。透けて見える現在地図は古地図の存在を意味しません。','Source: Konjaku Map (originals: GSI and predecessors). Blue outlines are map sheets, not full regional coverage. Blank, out-of-sheet or missing areas cannot be compared. A current map underneath does not establish historical coverage.');
  $('#history-center').textContent=sheets.length?t('地図中央の図幅：','Sheet at map center: ')+sheets.map(s=>s.name+' — '+(s.note||t('測量・作成年未取得','Survey/compilation date unavailable'))).join(' / ')+t('（提供元の図歴表記。収録年代と測量・発行年は異なる場合があります。）',' (Original Japanese map history; period, survey and publication dates may differ.)'):t('地図中央は、この地域・年代の収録図幅の範囲外です。','Map center is outside the catalogued sheets for this region and period.');
  $('#history-provider').href='https://ktgis.net/kjmapw/kjmapw.html?lat='+center.lat+'&lng='+center.lng+'&zoom='+Math.max(8,Math.min(p.maxZoom,Math.round(z)))+'&dataset='+encodeURIComponent(region.id)+'&age='+terrain.period+'&map2type=roadmap&dual=true';
 }
}

'use strict';
let lang='ja';
try{lang=localStorage.getItem('atlas-language')==='en'?'en':'ja';}catch{}
const t=(ja,en)=>lang==='en'?en:ja;
const prefEnglish=['Hokkaido','Aomori','Iwate','Miyagi','Akita','Yamagata','Fukushima','Ibaraki','Tochigi','Gunma','Saitama','Chiba','Tokyo','Kanagawa','Niigata','Toyama','Ishikawa','Fukui','Yamanashi','Nagano','Gifu','Shizuoka','Aichi','Mie','Shiga','Kyoto','Osaka','Hyogo','Nara','Wakayama','Tottori','Shimane','Okayama','Hiroshima','Yamaguchi','Tokushima','Kagawa','Ehime','Kochi','Fukuoka','Saga','Nagasaki','Kumamoto','Oita','Miyazaki','Kagoshima','Okinawa'];
const prefLabel=p=>lang==='en'?(prefEnglish[prefOrder.indexOf(p)]||p):p;
const causeEnglish={'ボックスカルバート':'Box culvert','道路排水施設\n（側溝）':'Road drainage (side ditch)','要因未確定':'Undetermined','上水道':'Water supply','道路排水施設\n（横断水路）':'Road drainage (cross drain)','下水道':'Sewerage','道路排水施設\n（集水桝）':'Road drainage (catch basin)','ガス':'Gas','擁壁':'Retaining wall','通信管路':'Telecommunication duct','橋梁':'Bridge','共同溝':'Utility tunnel','河川施設（護岸等）':'River facility (revetment, etc.)','道路附属物':'Road accessory','道路排水施設':'Road drainage','その他道路施設':'Other road facility','その他':'Other','その他占用物件':'Other permitted utility','樹木':'Tree','通信':'Telecommunication','法面':'Slope','電力':'Electric power','地下鉄':'Subway','電線共同溝':'Cable utility duct','舗装':'Pavement','道路排水施設\n（縦断側溝・縦断管渠）':'Road drainage (longitudinal ditch / culvert)','道路排水施設\n（横断側溝・横断管渠）':'Road drainage (cross ditch / culvert)','その他占用施設':'Other permitted utility','工事・その他':'Construction / other'};
const causeLabel=c=>lang==='en'?(causeEnglish[c]||featuredEnglish[featured.find(r=>r.cause===c)?.id]?.cause||c):c;
const caseField=(r,k)=>lang==='en'?(featuredEnglish[r.id]?.[k]??r[k]):r[k];
const staticText={
'陥没アトラス':'Sinkhole Atlas','地図で探す':'Map','データ一覧':'Records','分布を読む':'Statistics','データについて':'About','出典照合':'Source checks',
'資料確認':'Checked','↓ CSV出力':'↓ Export CSV','足もとの記録を、':'The ground beneath us,','地図から知る。':'seen through records.',
'道路陥没の発生分布・規模・対策を':'Explore road collapses, dimensions and responses','公開資料からたどるデータベース。':'through traceable public sources.',
'全国調査':'National survey','対策履歴のある事例':'Case histories','対象年度':'Fiscal year','すべての年度':'All years','2025年度（令和7年度）':'FY 2025','2024年度（令和6年度）':'FY 2024','2023年度（令和5年度）':'FY 2023',
'都道府県':'Prefecture','原因・要因施設':'Cause / related facility','陥没の深さ':'Collapse depth','すべて':'All','20 cm以上':'At least 20 cm','50 cm以上':'At least 50 cm','1 m以上':'At least 1 m','2 m以上':'At least 2 m','3 m以上':'At least 3 m','未記載':'Not reported',
'住所から分かる範囲':'Location detail available','町丁目まで分かる':'Neighborhood identified','市区町村まで':'Municipality only','場所が不明（一覧のみ）':'Unlocated (list only)',
'地図の点は、どの場所を示す？':'What does a point on the map mean?',
'公表住所をもとに、町丁目または市区町村の代表位置に置いています。市区町村までの記録は、離れた事故も同じ点に重なります。細かな地域分布を見るときは「町丁目まで分かる」を選んでください。正確な事故地点は原資料で確認が必要です.':'Points represent neighborhoods or municipalities from published addresses.',
'地図の表示範囲に絞る':'Within the visible map','リセット':'Reset','検索結果':'Results','件':'records','年度・所在地順':'Year / location','深い順':'Deepest first','浅い順':'Shallowest first','平面規模の大きい順':'Largest footprint',
'全国の記録を読み込んでいます…':'Loading national records…','出典のある記録のみを掲載':'Every record has a source','絞り込み':'Filters',
'該当する記録':'Matching records','地図に表示できる記録':'Located records','深さの記載あり':'Depth reported','記録の分布を示します。':'Distribution of recorded events.','発生確率・危険度の地図ではありません。':'Not a hazard probability map.',
'分布を見る':'Distribution','点で詳しく':'Individual records','集計する範囲':'Grid size','色の濃さ':'Overlay','⌖ 日本全体':'⌖ All Japan',
'公開記録を、横断して調べる':'Explore the source records','行をクリックすると、位置・規模・原資料を確認できます。':'Select a row to see location, dimensions and original sources.',
'年度 / 発生日':'Year / date','所在地・路線':'Location / road','要因':'Related facility','深さ':'Depth','縦 × 横':'Length × width',
'出典：国土交通省・地方公共団体等 ／ 編集：陥没アトラス':'Sources: MLIT / local authorities · Edited by Sinkhole Atlas',
'住所・路線名・キーワード':'Address, road or keyword','陥没アトラス ホーム':'Sinkhole Atlas home','表示切替':'Views','検索と絞り込み':'Search and filters','データの種類':'Dataset','並び順':'Sort order','収録範囲について':'About the coverage','データ表示':'Data view','絞り込みを開く':'Open filters','日本の陥没記録地図':'Japan sinkhole record map','地図の表示方法':'Map display','日本全体を表示':'Show all Japan','記録の詳細':'Record details'
};
staticText['公表住所をもとに、町丁目または市区町村の代表位置に置いています。市区町村までの記録は、離れた事故も同じ点に重なります。細かな地域分布を見るときは「町丁目まで分かる」を選んでください。正確な事故地点は原資料で確認が必要です。']='Points represent neighborhoods or municipalities, based on published addresses. Municipality-only records can share one point even when events occurred far apart. Choose “Neighborhood identified” to explore finer patterns. Consult the source to locate an actual collapse.';
Object.assign(staticText, {"下限":"From","上限":"To","深さの範囲":"Depth range","深さの下限を設定":"Set the minimum depth","深さ未記載の記録":"Unreported depth","含める":"Include","除く":"Exclude","未記載のみ":"Not reported only","上下限を含む範囲です。範囲を変えると、深さ未記載の記録を除きます。":"Both limits are inclusive. Changing depth limits excludes records with unreported depth."});
Object.assign(staticText, {"道路陥没マップ":"Road Sinkhole Map","道路陥没マップ ホーム":"Road Sinkhole Map home","陥没の実態をとらえ、":"Understand road collapses.","未然に防ぐ。":"Prevent them before they happen.","公開資料をもとに、全国の道路陥没事例をまとめています。":"Road collapse cases across Japan, compiled from public sources.","地図上で発生場所を確認し、陥没の規模や原因、対策を調べることができます。":"Explore locations on the map and investigate collapse dimensions, causes and responses.","以上":"At least","以下":"At most","指定なし":"Any","出典：国土交通省・地方公共団体等":"Sources: MLIT / local authorities"});
Object.assign(staticText, {'から':'From','まで':'To','陥没の実態を':'Making road collapses','見える化する':'visible'});
const originalNodes=new WeakMap(), originalAttrs=new WeakMap();
function localizeStatic(){
 const walker=document.createTreeWalker(document.body,NodeFilter.SHOW_TEXT);
 let node;while(node=walker.nextNode()){
  if(['SCRIPT','STYLE','NOSCRIPT'].includes(node.parentElement?.tagName))continue;
  let original=originalNodes.get(node);
  if(!original){original=node.textContent;originalNodes.set(node,original);}
  const key=original.trim();if(staticText[key])node.textContent=lang==='en'?original.replace(key,staticText[key]):original;
 }
 document.querySelectorAll('[placeholder],[aria-label],[title]').forEach(el=>{
  let attrs=originalAttrs.get(el);if(!attrs){attrs={};['placeholder','aria-label','title'].forEach(a=>{if(el.hasAttribute(a))attrs[a]=el.getAttribute(a);});originalAttrs.set(el,attrs);}
  Object.entries(attrs).forEach(([a,v])=>{if(staticText[v])el.setAttribute(a,lang==='en'?staticText[v]:v);});
 });
 document.documentElement.lang=lang;
 document.title=t('道路陥没マップ｜道路陥没データベース','Road Sinkhole Map | Japan Road Collapse Database');
 $('#lang-ja').setAttribute('aria-pressed',String(lang==='ja'));$('#lang-en').setAttribute('aria-pressed',String(lang==='en'));
}
function setLanguage(next){
 if(lang===next)return;lang=next;try{localStorage.setItem('atlas-language',lang);}catch{}
 localizeStatic();populateFilters();filterRecords();setView(view);
 if(selected)openDetail(selected,false,false);if(candidateState){const scroll=$('.sidebar').scrollTop;renderCandidates();$('.sidebar').scrollTop=scroll;}
}

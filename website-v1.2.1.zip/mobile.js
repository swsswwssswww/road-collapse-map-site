'use strict';
const mobileMedia=matchMedia('(max-width: 900px)');
let mobileReady=false;
const mobileHomes=new Map();
function closeMobilePanels(){}
function openMobilePanel(panel){
 if(!mobileReady)return;
 if(panel==='filters'){setView('map');$('#mobile-filter-section').scrollIntoView({block:'start'});}
 else{closeDetail();$('.sidebar').scrollIntoView({block:'start'});}
}
function syncMobileDetail(){updatePanel();}
function updateMobileUI(){
 if(!mobileReady)return;
 const set=(id,ja,en)=>$('#'+id).textContent=t(ja,en);
 set('mobile-map','地図','Map');set('mobile-filters','絞り込み','Filters');set('mobile-results-label','検索結果','Results');set('mobile-result-count',fmt(filtered.length)+'件',fmt(filtered.length));
 set('mobile-filter-title','絞り込み','Filters');set('mobile-filter-apply',fmt(filtered.length)+'件を地図で見る ↑','Show '+fmt(filtered.length)+' on map ↑');
 set('mobile-settings-title','地図の表示・色分け','Map display & colors');set('mobile-settings-done','地図に戻る ↑','Back to map ↑');
 set('display-settings-summary','地図の表示・色分け','Map display & colors');
 set('mobile-disclaimer','住所の代表位置を表示しています。危険度を示す地図ではありません。','Representative locations, not exact incident points or a hazard map.');
 $('#mobile-settings').hidden=view!=='map';$('#mobile-filter-section').hidden=!mobileMedia.matches;
 $('.mobile-actions').hidden=view!=='map';$('#mobile-disclaimer').hidden=view!=='map';$('#terrain-tools').hidden=view!=='map';$('.attribution-footer')&&($('.attribution-footer').hidden=view!=='map');
 const labels={map:['地図','Map'],table:['データ一覧','Records'],stats:['分布','Patterns'],sources:['データについて','About'],audit:['出典照合','Checks']};
 $$('.header .nav').forEach(b=>b.textContent=t(...labels[b.dataset.view]));
 $('#mobile-results').removeAttribute('aria-haspopup');$('#mobile-results').setAttribute('aria-controls','browse-panel');
 syncMobileDetail();if(typeof updateTerrainUI==='function')updateTerrainUI();
}
function wireMobileUI(){
 if(mobileReady)return;mobileReady=true;
 const sidebar=$('.sidebar'),filters=$('.filter-area');
 for(const node of [sidebar,filters]){const anchor=document.createComment('desktop home');node.before(anchor);mobileHomes.set(node,anchor);}
 $('#mobile-display-controls').append($('.map-controls'));
 $('#mobile-settings-body').append($('#density-options'),$('#legend'),$('#map-notice'));
 $('#mobile-settings-body').prepend($('#overlay-opacity').closest('label'));
 const settings=$('#mobile-settings'),summary=document.createElement('summary');summary.id='display-settings-summary';summary.textContent=t('地図の表示・色分け','Map display & colors');settings.prepend(summary);
 const applyLayout=()=>{
  if(mobileMedia.matches){$('#mobile-filter-body').append(filters);$('#mobile-filter-section').after(sidebar);}
  else{for(const [node,anchor]of mobileHomes)anchor.after(node);}
  updateMobileUI();requestAnimationFrame(()=>map?.invalidateSize());
 };
 mobileMedia.addEventListener('change',applyLayout);
 const returnToMap=()=>{setView('map');$('#pane-map').scrollIntoView({block:'start'});};
 $('#mobile-map').onclick=returnToMap;$('#mobile-filters').onclick=()=>openMobilePanel('filters');$('#mobile-results').onclick=()=>openMobilePanel('results');
 $('#mobile-settings-done').onclick=returnToMap;$('#mobile-filter-apply').onclick=returnToMap;
 $('#toggle-sidebar').onclick=()=>openMobilePanel('filters');
 applyLayout();
}
